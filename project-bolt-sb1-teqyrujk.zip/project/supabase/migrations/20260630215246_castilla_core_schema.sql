/*
# Castilla Core Schema Migration

## Overview
Creates the complete database schema for Castilla — a premium handcrafted gifting
and home décor e-commerce brand based in Karachi. This is a single-tenant schema
(no per-user data isolation — admin uses Supabase Auth, customers place orders anonymously).

## New Tables

### products
Stores all product listings with full e-commerce fields.
- id: UUID primary key
- slug: unique URL-friendly identifier
- name: product display name
- category: product category (Scented Candles, Candle Bouquets, etc.)
- short_description: brief product blurb for cards
- description: full rich product description
- price: numeric price in PKR
- price_type: 'fixed' | 'from' | 'custom' | 'quote'
- compare_at_price: optional strike-through price
- image_url: primary product image URL
- gallery_images: JSONB array of additional image URLs
- tags: JSONB array of product tags
- occasions: JSONB array of occasions (Birthday, Wedding, etc.)
- options: JSONB array of product options (scent, size, etc.)
- stock_status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'made_to_order'
- quantity_available: optional inventory count
- is_featured: shown on homepage featured section
- is_bestseller: shown with bestseller badge
- is_customizable: can be customized
- is_bulk_friendly: suitable for bulk orders
- display_order: sort order for admin control
- seo_title, seo_description: SEO fields

### orders
Customer orders placed through the storefront.
- id: UUID primary key
- order_number: human-readable unique order ID (e.g. CAS-10001)
- customer_name, phone, email: customer contact info
- delivery_city, delivery_address: shipping details
- payment_method: Cash on Delivery, Bank Transfer, Easypaisa, JazzCash
- items: JSONB array of ordered products with qty/price
- subtotal, total: pricing totals in PKR
- notes: customer order notes
- status: New | Contacted | Confirmed | Preparing | Ready for Dispatch | Completed | Cancelled
- source: 'website' | 'whatsapp' | 'instagram'
- admin_notes: internal admin notes

### custom_gift_requests
Custom gift pack requests from customers.

### bulk_requests
Bulk/event/corporate gifting requests.

### site_settings
Key-value store for all site configuration (announcement bar, hero text, contact info, etc.)

### instagram_items
Admin-managed Instagram carousel items for homepage.

### faqs
FAQ entries for the FAQ page and homepage preview.

## Security (RLS)
- products: anon can SELECT (browse), authenticated (admin) can INSERT/UPDATE/DELETE
- orders: anon+authenticated can INSERT (place order), authenticated (admin) can SELECT/UPDATE
- custom_gift_requests, bulk_requests: anon+authenticated can INSERT, authenticated can SELECT/UPDATE
- site_settings, instagram_items, faqs: anon can SELECT, authenticated can INSERT/UPDATE/DELETE
*/

-- ============================================================
-- PRODUCTS
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'Scented Candles',
  short_description text DEFAULT '',
  description text DEFAULT '',
  price numeric(10,2) NOT NULL DEFAULT 0,
  price_type text NOT NULL DEFAULT 'fixed',
  compare_at_price numeric(10,2),
  image_url text DEFAULT '',
  gallery_images jsonb DEFAULT '[]'::jsonb,
  tags jsonb DEFAULT '[]'::jsonb,
  occasions jsonb DEFAULT '[]'::jsonb,
  options jsonb DEFAULT '[]'::jsonb,
  stock_status text NOT NULL DEFAULT 'in_stock',
  quantity_available integer,
  is_featured boolean NOT NULL DEFAULT false,
  is_bestseller boolean NOT NULL DEFAULT false,
  is_customizable boolean NOT NULL DEFAULT false,
  is_bulk_friendly boolean NOT NULL DEFAULT false,
  display_order integer NOT NULL DEFAULT 0,
  seo_title text DEFAULT '',
  seo_description text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_products" ON products;
CREATE POLICY "admin_insert_products" ON products FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_products" ON products;
CREATE POLICY "admin_update_products" ON products FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_products" ON products;
CREATE POLICY "admin_delete_products" ON products FOR DELETE
  TO authenticated USING (true);

-- ============================================================
-- ORDERS
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  customer_name text NOT NULL,
  phone text NOT NULL,
  email text DEFAULT '',
  delivery_city text NOT NULL,
  delivery_address text NOT NULL,
  payment_method text NOT NULL DEFAULT 'Cash on Delivery',
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  status text NOT NULL DEFAULT 'New',
  source text NOT NULL DEFAULT 'website',
  admin_notes text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_select_orders" ON orders;
CREATE POLICY "admin_select_orders" ON orders FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_orders" ON orders;
CREATE POLICY "admin_update_orders" ON orders FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- ============================================================
-- CUSTOM GIFT REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS custom_gift_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  email text DEFAULT '',
  occasion text DEFAULT '',
  preferred_products jsonb DEFAULT '[]'::jsonb,
  budget_range text DEFAULT '',
  delivery_city text DEFAULT '',
  required_date date,
  message text DEFAULT '',
  status text NOT NULL DEFAULT 'New',
  admin_notes text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE custom_gift_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_custom_requests" ON custom_gift_requests;
CREATE POLICY "anon_insert_custom_requests" ON custom_gift_requests FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_select_custom_requests" ON custom_gift_requests;
CREATE POLICY "admin_select_custom_requests" ON custom_gift_requests FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_custom_requests" ON custom_gift_requests;
CREATE POLICY "admin_update_custom_requests" ON custom_gift_requests FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- ============================================================
-- BULK REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS bulk_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company_event_name text DEFAULT '',
  phone text NOT NULL,
  email text DEFAULT '',
  event_type text DEFAULT '',
  estimated_quantity integer DEFAULT 0,
  delivery_cities text DEFAULT '',
  preferred_products jsonb DEFAULT '[]'::jsonb,
  required_date date,
  budget_range text DEFAULT '',
  message text DEFAULT '',
  status text NOT NULL DEFAULT 'New',
  admin_notes text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE bulk_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_bulk_requests" ON bulk_requests;
CREATE POLICY "anon_insert_bulk_requests" ON bulk_requests FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_select_bulk_requests" ON bulk_requests;
CREATE POLICY "admin_select_bulk_requests" ON bulk_requests FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_bulk_requests" ON bulk_requests;
CREATE POLICY "admin_update_bulk_requests" ON bulk_requests FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- ============================================================
-- SITE SETTINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS site_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_settings" ON site_settings;
CREATE POLICY "anon_select_settings" ON site_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_settings" ON site_settings;
CREATE POLICY "admin_insert_settings" ON site_settings FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_settings" ON site_settings;
CREATE POLICY "admin_update_settings" ON site_settings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_settings" ON site_settings;
CREATE POLICY "admin_delete_settings" ON site_settings FOR DELETE
  TO authenticated USING (true);

-- ============================================================
-- INSTAGRAM ITEMS
-- ============================================================
CREATE TABLE IF NOT EXISTS instagram_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL DEFAULT '',
  caption text DEFAULT '',
  link text DEFAULT '',
  display_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE instagram_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_instagram" ON instagram_items;
CREATE POLICY "anon_select_instagram" ON instagram_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_instagram" ON instagram_items;
CREATE POLICY "admin_insert_instagram" ON instagram_items FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_instagram" ON instagram_items;
CREATE POLICY "admin_update_instagram" ON instagram_items FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_instagram" ON instagram_items;
CREATE POLICY "admin_delete_instagram" ON instagram_items FOR DELETE
  TO authenticated USING (true);

-- ============================================================
-- FAQS
-- ============================================================
CREATE TABLE IF NOT EXISTS faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  answer text NOT NULL,
  category text DEFAULT 'General',
  display_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_faqs" ON faqs;
CREATE POLICY "anon_select_faqs" ON faqs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_faqs" ON faqs;
CREATE POLICY "admin_insert_faqs" ON faqs FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_faqs" ON faqs;
CREATE POLICY "admin_update_faqs" ON faqs FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_faqs" ON faqs;
CREATE POLICY "admin_delete_faqs" ON faqs FOR DELETE
  TO authenticated USING (true);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_products_slug ON products(slug);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_is_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_products_display_order ON products(display_order);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_instagram_display_order ON instagram_items(display_order);
CREATE INDEX IF NOT EXISTS idx_faqs_display_order ON faqs(display_order);
