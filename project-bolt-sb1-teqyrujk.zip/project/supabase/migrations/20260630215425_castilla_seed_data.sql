/*
# Castilla Seed Data Migration

## Overview
Seeds the Castilla database with demo products, site settings, Instagram items,
and FAQs so the storefront works out-of-the-box. All prices, images, and content
are clearly marked as demo placeholders that the admin should update before launch.

## Seeded Data
1. 12 demo products across all 7 product categories with PKR prices
2. Default site settings (announcement bar, hero text, contact info, payment methods)
3. 6 Instagram carousel items (placeholder images)
4. 8 FAQs covering ordering, delivery, customization, payment

## Notes
- All product images use Unsplash free images as placeholders
- Real prices to be confirmed with business owner before launch
- Replace all image_url fields with actual product photography
*/

-- ============================================================
-- SEED PRODUCTS (12 demo products)
-- ============================================================
INSERT INTO products (slug, name, category, short_description, description, price, price_type, compare_at_price, image_url, gallery_images, tags, occasions, options, stock_status, is_featured, is_bestseller, is_customizable, is_bulk_friendly, display_order) VALUES

('vanilla-amber-pillar-candle', 'Vanilla Amber Pillar Candle', 'Scented Candles',
 'A warm, creamy vanilla candle with notes of amber and sandalwood. Perfect for cosy evenings.',
 'Hand-poured with a premium soy-paraffin blend, this Vanilla Amber pillar candle fills your space with a warm, inviting fragrance. Notes of pure vanilla, rich amber, and subtle sandalwood create a grounding, luxurious scent. Burns cleanly for up to 45 hours. Available in a signature concrete-finish vessel.',
 2200, 'fixed', 2800,
 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=800',
 '["https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=800","https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=800"]'::jsonb,
 '["candle","vanilla","amber","soy","pillar"]'::jsonb,
 '["Home Décor","Self Care","Birthday","Anniversary","Thank You"]'::jsonb,
 '[{"name":"Scent","values":["Vanilla Amber","Rose & Oud","Jasmine Dusk"]},{"name":"Size","values":["Small (150g)","Medium (250g)","Large (400g)"]}]'::jsonb,
 'in_stock', true, true, false, true, 1),

('rose-oud-soy-candle', 'Rose & Oud Soy Candle', 'Scented Candles',
 'An intoxicating blend of fresh rose petals and deep, smoky oud. A premium signature scent.',
 'This Rose & Oud soy candle is one of Castilla''s most-loved signatures. Fresh rose petals meet deep, smoky oud in a fragrance that feels timeless and celebratory. Hand-poured in small batches using a clean soy wax blend. Burns for up to 50 hours.',
 2600, 'fixed', 3200,
 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800',
 '["https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800"]'::jsonb,
 '["candle","rose","oud","soy","luxury"]'::jsonb,
 '["Birthday","Wedding","Anniversary","Engagement","Bridal Shower","Self Care"]'::jsonb,
 '[{"name":"Size","values":["Medium (250g)","Large (400g)"]}]'::jsonb,
 'in_stock', true, true, false, true, 2),

('floral-candle-bouquet-pastel', 'Pastel Floral Candle Bouquet', 'Candle Bouquets',
 'A stunning arrangement of handcrafted taper candles styled as a floral bouquet. A gift that glows.',
 'The Pastel Floral Candle Bouquet is a handcrafted arrangement of delicate taper and petal candles in soft blush, ivory, and champagne tones. Each piece is sculpted by hand, making every bouquet unique. Arrives beautifully wrapped — no additional gifting needed. A show-stopping gift for weddings, birthdays, and celebrations.',
 4500, 'from', 6000,
 'https://images.unsplash.com/photo-1563241527-3004b7be0b60?w=800',
 '["https://images.unsplash.com/photo-1563241527-3004b7be0b60?w=800","https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=800"]'::jsonb,
 '["bouquet","candle","floral","pastel","gift","handcrafted"]'::jsonb,
 '["Birthday","Wedding","Bridal Shower","Engagement","Anniversary","Thank You"]'::jsonb,
 '[{"name":"Size","values":["Small (5 stems)","Medium (9 stems)","Large (15 stems)"]},{"name":"Colour Palette","values":["Pastel Blush","All White","Champagne & Gold","Custom"]}]'::jsonb,
 'in_stock', true, true, true, true, 3),

('luxury-concrete-tray', 'Luxury Concrete Tray', 'Concrete Trays',
 'A beautifully hand-finished concrete tray for styling your candles, perfumes, and home accessories.',
 'Crafted from a fine concrete blend and hand-finished with a smooth matte surface, this tray brings understated luxury to any home. Use it to style your candles, perfumes, jewellery, or seasonal décor. Available in Warm Grey, Blush, and Charcoal finishes. Each piece is slightly unique due to the handmade process.',
 3200, 'fixed', null,
 'https://images.unsplash.com/photo-1616627561839-074385245ff6?w=800',
 '["https://images.unsplash.com/photo-1616627561839-074385245ff6?w=800"]'::jsonb,
 '["tray","concrete","home décor","styling","minimalist"]'::jsonb,
 '["Home Décor","Wedding","Anniversary","Thank You","Corporate/Event"]'::jsonb,
 '[{"name":"Finish","values":["Warm Grey","Blush","Charcoal"]},{"name":"Size","values":["Small (20cm)","Medium (30cm)","Large (40cm)"]}]'::jsonb,
 'in_stock', false, false, false, true, 4),

('customized-fondant-cake', 'Customised Celebration Cake', 'Customized Cakes',
 'A beautifully customised celebration cake decorated to match your occasion. Enquire for flavours and design.',
 'Castilla''s customised celebration cakes are baked fresh and decorated entirely to order. Choose your flavours, tier count, colour palette, and décor style. Perfect for birthdays, weddings, engagements, and special milestones. Minimum order: 3 days ahead. Available for Karachi delivery or pickup.',
 4800, 'from', null,
 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800',
 '["https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800","https://images.unsplash.com/photo-1557925923-cd4648e211a0?w=800"]'::jsonb,
 '["cake","custom","celebration","fondant","birthday","wedding"]'::jsonb,
 '["Birthday","Wedding","Engagement","Anniversary","Bridal Shower","Eid"]'::jsonb,
 '[{"name":"Flavour","values":["Red Velvet","Vanilla Bean","Chocolate Fudge","Lemon Drizzle","Black Forest"]},{"name":"Tiers","values":["1 Tier","2 Tiers","3 Tiers"]}]'::jsonb,
 'made_to_order', true, false, true, false, 5),

('bubble-candle-set', 'Bubble Candle Set', 'Bubble Candles',
 'Playful, sculptural bubble candles in three elegant tones. A modern home décor favourite.',
 'These sculptural bubble candles have become one of Castilla''s most photographed pieces. Made from premium paraffin wax, each set of three is available in tonal or mixed colour combinations. Unscented. Perfect for table styling, gifting, and interiors. Burns cleanly with a beautiful glow.',
 1800, 'fixed', 2200,
 'https://images.unsplash.com/photo-1531259922257-f50440d6a2fb?w=800',
 '["https://images.unsplash.com/photo-1531259922257-f50440d6a2fb?w=800"]'::jsonb,
 '["bubble candle","sculptural","décor","modern","set"]'::jsonb,
 '["Home Décor","Birthday","Self Care","Thank You","Bridal Shower"]'::jsonb,
 '[{"name":"Colour Set","values":["Blush & Ivory","Champagne Tones","Terracotta Mix","All White","Custom"]}]'::jsonb,
 'in_stock', true, true, false, true, 6),

('elegance-gift-pack', 'Elegance Gift Pack', 'Pre-Made Gift Packs',
 'A curated gift pack featuring a scented candle, bubble candles, and a concrete tray. Ready to gift.',
 'The Elegance Gift Pack is thoughtfully curated for effortless gifting. Each pack includes a medium scented candle, a set of bubble candles, and a mini concrete tray — presented in a signature Castilla gift box with tissue and ribbon. No additional wrapping needed. Available in Blush or Champagne colourways.',
 5500, 'fixed', 7000,
 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800',
 '["https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800","https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=800"]'::jsonb,
 '["gift pack","curated","ready to gift","candle","tray","luxury"]'::jsonb,
 '["Birthday","Anniversary","Thank You","Bridal Shower","Self Care","Eid"]'::jsonb,
 '[{"name":"Colourway","values":["Blush & Rose Gold","Champagne & Ivory"]}]'::jsonb,
 'in_stock', true, true, false, true, 7),

('celebration-gift-pack', 'Celebration Gift Pack', 'Pre-Made Gift Packs',
 'A larger gift pack for special milestones — candle bouquet, scented candle, and tray in a premium box.',
 'The Celebration Gift Pack is designed for your most special occasions. Includes a small floral candle bouquet, a large scented candle, and a medium concrete tray, presented in our premium gift box. Perfect for weddings, engagements, and milestone birthdays.',
 8500, 'fixed', 10500,
 'https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=800',
 '["https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=800"]'::jsonb,
 '["gift pack","celebration","premium","wedding","milestone"]'::jsonb,
 '["Wedding","Engagement","Anniversary","Bridal Shower","Birthday"]'::jsonb,
 '[{"name":"Candle Scent","values":["Vanilla Amber","Rose & Oud","Jasmine Dusk"]}]'::jsonb,
 'in_stock', false, false, false, true, 8),

('jasmine-dusk-candle', 'Jasmine Dusk Reed Diffuser', 'Scented Candles',
 'A delicate jasmine and white musk reed diffuser for continuous fragrance. Elegant and long-lasting.',
 'The Jasmine Dusk Reed Diffuser delivers a continuous, delicate fragrance with notes of night-blooming jasmine, soft white musk, and a whisper of fresh linen. Lasts up to 90 days. Comes with 8 natural rattan reeds in a glass vessel. A quiet luxury for bedrooms, living rooms, and bathrooms.',
 3000, 'fixed', null,
 'https://images.unsplash.com/photo-1616627452198-4c2b2a7a1c49?w=800',
 '["https://images.unsplash.com/photo-1616627452198-4c2b2a7a1c49?w=800"]'::jsonb,
 '["diffuser","jasmine","reed","fragrance","home"]'::jsonb,
 '["Home Décor","Self Care","Anniversary","Thank You","Corporate/Event"]'::jsonb,
 '[]'::jsonb,
 'in_stock', false, false, false, true, 9),

('eid-gift-set', 'Eid Festive Gift Set', 'Pre-Made Gift Packs',
 'A beautifully wrapped Eid gift set with a scented candle, tray, and festive packaging.',
 'Celebrate Eid with Castilla''s festive gift set. Includes a large scented candle in Rose & Oud or Oud & Amber, a small concrete tray, and a set of decorative bubble candles — all presented in our gold-accented Eid packaging with a handwritten gift card.',
 6500, 'fixed', null,
 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800',
 '["https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800"]'::jsonb,
 '["eid","gift set","festive","candle","tray"]'::jsonb,
 '["Eid","Birthday","Thank You","Anniversary"]'::jsonb,
 '[{"name":"Candle Scent","values":["Rose & Oud","Oud & Amber","Vanilla Amber"]}]'::jsonb,
 'in_stock', true, false, false, true, 10),

('custom-gift-pack-builder', 'Build Your Own Gift Pack', 'Custom Gift Packs',
 'Choose your own combination of products and we will pack and present it as a premium gift.',
 'Can''t find exactly what you are looking for? Build your own gift pack from any of Castilla''s products. Choose your combination, tell us your occasion, and we will pack everything beautifully in our signature gifting boxes. Price depends on selected products. Request a custom quote below.',
 0, 'custom', null,
 'https://images.unsplash.com/photo-1512909006721-3d6018887383?w=800',
 '["https://images.unsplash.com/photo-1512909006721-3d6018887383?w=800"]'::jsonb,
 '["custom","build your own","gift pack","personalized"]'::jsonb,
 '["Birthday","Wedding","Engagement","Anniversary","Bridal Shower","Eid","Corporate/Event"]'::jsonb,
 '[]'::jsonb,
 'in_stock', true, false, true, true, 11),

('concrete-candle-holder-set', 'Concrete Candle Holder Set', 'Concrete Trays',
 'A set of three graduated concrete candle holders in warm grey. Minimal and modern.',
 'Three graduated concrete candle holders in a warm grey finish. Hold taper or pillar candles and create a beautiful arrangement on your dining table, console, or mantle. Each piece is hand-cast and finished, with natural variations that make every set unique.',
 2800, 'fixed', null,
 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800',
 '["https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800"]'::jsonb,
 '["concrete","candle holder","set","minimal","modern","décor"]'::jsonb,
 '["Home Décor","Wedding","Corporate/Event","Anniversary"]'::jsonb,
 '[{"name":"Finish","values":["Warm Grey","Matte Black","Blush"]}]'::jsonb,
 'in_stock', false, false, false, true, 12)

ON CONFLICT (slug) DO NOTHING;

-- ============================================================
-- SEED SITE SETTINGS
-- ============================================================
INSERT INTO site_settings (key, value) VALUES
('announcement_bar', '{"text": "Free delivery on orders over Rs. 8,000 | Custom gift packs available | WhatsApp us for bulk orders", "is_active": true}'::jsonb),
('hero', '{"headline": "Beautiful Gifts, Thoughtfully Made", "subheadline": "Shop candles, candle bouquets, trays, cakes, bubble candles, and curated gift packs designed for warm homes, thoughtful gestures, and elegant celebrations.", "trust_line": "Handcrafted gifting · Custom packs · Nationwide delivery"}'::jsonb),
('contact', '{"phone": "", "whatsapp": "", "instagram_url": "", "email": "", "address": "Karachi, Pakistan"}'::jsonb),
('delivery', '{"note": "Orders are confirmed after product availability and delivery details are reviewed. Delivery is available across Pakistan. Delivery charges and timelines will be confirmed with your order.", "cities": ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Hyderabad", "Peshawar"]}'::jsonb),
('payment_methods', '{"methods": [{"id": "cod", "name": "Cash on Delivery", "is_active": true}, {"id": "bank_transfer", "name": "Bank Transfer", "is_active": true}, {"id": "easypaisa", "name": "Easypaisa", "is_active": true}, {"id": "jazzcash", "name": "JazzCash", "is_active": true}]}'::jsonb),
('seo', '{"site_title": "Castilla — Handcrafted Gifting & Home Décor", "meta_description": "Shop premium handcrafted candles, candle bouquets, concrete trays, customised cakes, bubble candles, and gift packs. Custom and bulk gifting available. Nationwide delivery across Pakistan.", "og_image": ""}'::jsonb),
('footer', '{"tagline": "Handcrafted with care, curated with love.", "copyright": "© 2024 Castilla. All rights reserved."}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- SEED INSTAGRAM ITEMS
-- ============================================================
INSERT INTO instagram_items (image_url, caption, link, display_order, is_active) VALUES
('https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=600', 'Warm evenings call for warm light 🕯️', '', 1, true),
('https://images.unsplash.com/photo-1563241527-3004b7be0b60?w=600', 'Custom candle bouquet for a beautiful birthday 🌸', '', 2, true),
('https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600', 'Rose & Oud — our best-loved scent ✨', '', 3, true),
('https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600', 'The Elegance Gift Pack. Ready to gift. 🎁', '', 4, true),
('https://images.unsplash.com/photo-1531259922257-f50440d6a2fb?w=600', 'Bubble candles in blush & ivory 🫧', '', 5, true),
('https://images.unsplash.com/photo-1616627561839-074385245ff6?w=600', 'Styling a concrete tray for the season 🤍', '', 6, true)
ON CONFLICT DO NOTHING;

-- ============================================================
-- SEED FAQS
-- ============================================================
INSERT INTO faqs (question, answer, category, display_order, is_active) VALUES
('How do I place an order?', 'Browse our shop, add products to your cart, and proceed to checkout. Fill in your details and choose your payment method. Your order will be confirmed after we review availability and delivery details. You can also send your order summary directly to us on WhatsApp.', 'Ordering', 1, true),
('Do you deliver across Pakistan?', 'Yes, we deliver nationwide. Delivery charges and timelines vary by city and will be confirmed with your order. Standard delivery to Karachi takes 1–2 business days; outstation deliveries typically take 3–5 business days.', 'Delivery', 2, true),
('Can I build a custom gift pack?', 'Absolutely. Visit our Custom Gift Pack page, fill in your preferences — occasion, budget, preferred products — and we will put together a personalised pack for you. Custom quotes are confirmed within 24 hours.', 'Custom Orders', 3, true),
('What payment methods do you accept?', 'We accept Cash on Delivery, Bank Transfer, Easypaisa, and JazzCash. Your preferred payment method is selected at checkout and confirmed when we process your order.', 'Payment', 4, true),
('How far in advance should I order a customised cake?', 'Customised cakes require a minimum of 3 business days'' notice. For elaborate designs or larger orders, we recommend ordering at least 5–7 days ahead to ensure everything is perfect.', 'Custom Orders', 5, true),
('Are the candles made with natural wax?', 'Our candles are hand-poured using a premium soy-paraffin blend chosen for clean burning, excellent scent throw, and a beautiful finish. All fragrances are skin-safe and non-toxic.', 'Products', 6, true),
('Do you offer bulk or corporate gifting?', 'Yes. We offer custom bulk and corporate gifting for weddings, events, and businesses. Visit our Bulk Gifting page to submit a request, and we will get back to you with a tailored quote within 24 hours.', 'Bulk Orders', 7, true),
('Can I add a personalised message to my order?', 'Yes. Add your message in the order notes field at checkout, or let us know via WhatsApp after placing your order. We include a handwritten gift card at no extra charge.', 'Ordering', 8, true)
ON CONFLICT DO NOTHING;
