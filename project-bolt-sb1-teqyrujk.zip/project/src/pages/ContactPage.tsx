import { useState } from 'react'
import { MessageCircle, Phone, Camera, Mail, CheckCircle2, ArrowRight } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'

export function ContactPage() {
  const whatsapp = import.meta.env.VITE_WHATSAPP_NUMBER
  const instagramUrl = import.meta.env.VITE_INSTAGRAM_URL
  const phone = import.meta.env.VITE_CONTACT_PHONE
  const email = import.meta.env.VITE_EMAIL_ADDRESS

  const [form, setForm] = useState({ name: '', phone: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim() || !form.message.trim()) return
    // Build WhatsApp message
    const msg = `Hi Castilla!\n\nName: ${form.name}\nPhone: ${form.phone}\n\nMessage: ${form.message}`
    window.open(`https://wa.me/${whatsapp}?text=${encodeURIComponent(msg)}`, '_blank')
    setSent(true)
  }

  return (
    <div>
      {/* Hero */}
      <div className="py-20 px-4 sm:px-6 text-center bg-card border-b border-border">
        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Get in Touch</p>
        <h1 className="font-serif text-5xl text-foreground mb-4">Contact Us</h1>
        <p className="font-sans text-muted-foreground max-w-md mx-auto leading-relaxed">
          Have a question about an order, a product, or a custom request? We'd love to hear from you.
        </p>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid md:grid-cols-2 gap-16">
          {/* Contact channels */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-8">Reach Us</h2>
            <div className="space-y-5">
              {whatsapp && (
                <a
                  href={`https://wa.me/${whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-xl border border-border hover:border-green-300 hover:bg-green-50/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-sans text-sm font-semibold text-foreground group-hover:text-green-700">WhatsApp</p>
                    <p className="font-sans text-sm text-muted-foreground">Fastest response · usually within hours</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground ml-auto" />
                </a>
              )}
              {instagramUrl && (
                <a
                  href={instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-xl border border-border hover:border-pink-300 hover:bg-pink-50/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
                    <Camera className="w-5 h-5 text-pink-600" />
                  </div>
                  <div>
                    <p className="font-sans text-sm font-semibold text-foreground group-hover:text-pink-700">Instagram</p>
                    <p className="font-sans text-sm text-muted-foreground">DM us or tag us in your posts</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground ml-auto" />
                </a>
              )}
              {phone && (
                <a
                  href={`tel:${phone}`}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border hover:border-primary/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-sans text-sm font-semibold text-foreground">Phone</p>
                    <p className="font-sans text-sm text-muted-foreground">{phone}</p>
                  </div>
                </a>
              )}
              {email && (
                <a
                  href={`mailto:${email}`}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border hover:border-primary/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-sans text-sm font-semibold text-foreground">Email</p>
                    <p className="font-sans text-sm text-muted-foreground">{email}</p>
                  </div>
                </a>
              )}
            </div>

            <div className="mt-8 p-4 rounded-xl bg-accent border border-border">
              <p className="font-sans text-sm font-medium text-foreground mb-1">Response Times</p>
              <p className="font-sans text-xs text-muted-foreground leading-relaxed">
                WhatsApp messages are typically answered within a few hours. For custom and bulk orders, we respond within 24 hours with a proposal.
              </p>
            </div>
          </div>

          {/* Quick message form */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-8">Send a Message</h2>
            {sent ? (
              <div className="text-center py-12">
                <div className="w-14 h-14 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-7 h-7 text-green-600" />
                </div>
                <p className="font-serif text-2xl text-foreground mb-2">WhatsApp Opened!</p>
                <p className="font-sans text-sm text-muted-foreground">Your message was pre-filled. Send it in WhatsApp to reach us.</p>
              </div>
            ) : (
              <form onSubmit={handleSend} className="space-y-4">
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Your Name *</label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your name"
                    required
                    className="font-sans"
                  />
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Phone (optional)</label>
                  <Input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+92 or 0300..."
                    type="tel"
                    className="font-sans"
                  />
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Message *</label>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="How can we help you?"
                    rows={5}
                    required
                    className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                  />
                </div>
                <p className="font-sans text-xs text-muted-foreground">
                  This will open WhatsApp with your message pre-filled.
                </p>
                <Button type="submit" size="lg" className="w-full font-sans gap-2 bg-green-600 hover:bg-green-700 text-white">
                  <MessageCircle className="w-4 h-4" />
                  Send via WhatsApp
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
