import { useEffect, useState, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import { ProductCard } from '../components/storefront/ProductCard'
import { Input } from '../components/ui/input'
import { Button } from '../components/ui/button'
import { Badge } from '../components/ui/badge'
import { getProducts } from '../lib/api'
import type { Product } from '../lib/types'
import { CATEGORIES, OCCASIONS } from '../lib/types'

export function ShopPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchParams, setSearchParams] = useSearchParams()
  const [filtersOpen, setFiltersOpen] = useState(false)

  const querySearch = searchParams.get('q') || ''
  const queryCategory = searchParams.get('category') || ''
  const queryOccasion = searchParams.get('occasion') || ''
  const querySort = searchParams.get('sort') || 'default'

  const [localSearch, setLocalSearch] = useState(querySearch)

  useEffect(() => {
    getProducts()
      .then(setProducts)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    setLocalSearch(querySearch)
  }, [querySearch])

  const filtered = useMemo(() => {
    let list = [...products]

    if (localSearch) {
      const q = localSearch.toLowerCase()
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.short_description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          (p.tags as string[]).some((t) => t.toLowerCase().includes(q))
      )
    }

    if (queryCategory) {
      const cat = decodeURIComponent(queryCategory)
      list = list.filter((p) => p.category === cat)
    }

    if (queryOccasion) {
      const occ = decodeURIComponent(queryOccasion)
      list = list.filter((p) => (p.occasions as string[]).some((o) => o === occ || o.toLowerCase() === occ.toLowerCase()))
    }

    if (querySort === 'price_asc') list.sort((a, b) => a.price - b.price)
    else if (querySort === 'price_desc') list.sort((a, b) => b.price - a.price)
    else if (querySort === 'featured') list.sort((a, b) => (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0))

    return list
  }, [products, localSearch, queryCategory, queryOccasion, querySort])

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams)
    if (value) params.set(key, value)
    else params.delete(key)
    setSearchParams(params)
  }

  const clearAll = () => {
    setSearchParams({})
    setLocalSearch('')
  }

  const activeFilters = [
    queryCategory && { label: queryCategory, key: 'category' },
    queryOccasion && { label: queryOccasion, key: 'occasion' },
  ].filter(Boolean) as { label: string; key: string }[]

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <h1 className="font-serif text-4xl text-foreground mb-1">Shop</h1>
          <p className="font-sans text-sm text-muted-foreground">{filtered.length} products</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Toolbar */}
        <div className="flex flex-wrap gap-3 mb-6 items-center">
          {/* Search */}
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search products…"
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value)
                setFilter('q', e.target.value)
              }}
              className="pl-9 font-sans text-sm"
            />
          </div>

          {/* Filter toggle mobile */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="md:hidden font-sans gap-1.5"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
          </Button>

          {/* Desktop filters */}
          <div className="hidden md:flex items-center gap-2 flex-wrap">
            {/* Category */}
            <select
              className="h-9 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
              value={queryCategory}
              onChange={(e) => setFilter('category', e.target.value)}
            >
              <option value="">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            {/* Occasion */}
            <select
              className="h-9 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
              value={queryOccasion}
              onChange={(e) => setFilter('occasion', e.target.value)}
            >
              <option value="">All Occasions</option>
              {OCCASIONS.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>

            {/* Sort */}
            <select
              className="h-9 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
              value={querySort}
              onChange={(e) => setFilter('sort', e.target.value)}
            >
              <option value="default">Default Sort</option>
              <option value="featured">Featured First</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Mobile filters panel */}
        {filtersOpen && (
          <div className="md:hidden mb-6 p-4 rounded-xl border border-border bg-card space-y-3">
            <select
              className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm font-sans"
              value={queryCategory}
              onChange={(e) => setFilter('category', e.target.value)}
            >
              <option value="">All Categories</option>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select
              className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm font-sans"
              value={queryOccasion}
              onChange={(e) => setFilter('occasion', e.target.value)}
            >
              <option value="">All Occasions</option>
              {OCCASIONS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
            <select
              className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm font-sans"
              value={querySort}
              onChange={(e) => setFilter('sort', e.target.value)}
            >
              <option value="default">Default Sort</option>
              <option value="featured">Featured First</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        )}

        {/* Active filters */}
        {(activeFilters.length > 0 || localSearch) && (
          <div className="flex flex-wrap gap-2 mb-6 items-center">
            <span className="font-sans text-xs text-muted-foreground">Active:</span>
            {localSearch && (
              <Badge variant="secondary" className="font-sans text-xs gap-1">
                Search: {localSearch}
                <button onClick={() => { setLocalSearch(''); setFilter('q', '') }}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
            {activeFilters.map((f) => (
              <Badge key={f.key} variant="secondary" className="font-sans text-xs gap-1">
                {f.label}
                <button onClick={() => setFilter(f.key, '')}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            <button onClick={clearAll} className="font-sans text-xs text-muted-foreground hover:text-foreground underline">
              Clear all
            </button>
          </div>
        )}

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="rounded-xl bg-muted animate-pulse aspect-[3/4]" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="font-serif text-2xl text-muted-foreground mb-3">No products found</p>
            <p className="font-sans text-sm text-muted-foreground mb-6">Try adjusting your search or filters.</p>
            <Button variant="outline" onClick={clearAll} className="font-sans">Clear Filters</Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
