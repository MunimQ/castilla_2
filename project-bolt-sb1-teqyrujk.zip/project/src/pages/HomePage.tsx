import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, ChevronDown, ChevronUp, Package2, Users2 } from 'lucide-react'
import { HeroSection } from '../components/storefront/HeroSection'
import { TrustStrip } from '../components/storefront/TrustStrip'
import { CategoryGrid } from '../components/storefront/CategoryGrid'
import { ProductCard } from '../components/storefront/ProductCard'
import { InstagramCarousel } from '../components/storefront/InstagramCarousel'
import { Button } from '../components/ui/button'
import { getFeaturedProducts, getInstagramItems, getFAQs } from '../lib/api'
import type { Product, InstagramItem, FAQ } from '../lib/types'

export function HomePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [instagramItems, setInstagramItems] = useState<InstagramItem[]>([])
  const [faqs, setFaqs] = useState<FAQ[]>([])
  const [openFaq, setOpenFaq] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  const instagramUrl = import.meta.env.VITE_INSTAGRAM_URL
  const whatsapp = import.meta.env.VITE_WHATSAPP_NUMBER

  useEffect(() => {
    const load = async () => {
      try {
        const [prods, ig, faqData] = await Promise.all([
          getFeaturedProducts(),
          getInstagramItems(),
          getFAQs(),
        ])
        setProducts(prods)
        setInstagramItems(ig)
        setFaqs(faqData.slice(0, 4))
      } catch (err) {
        console.error('Failed to load homepage data:', err)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  return (
    <div>
      {/* Hero */}
      <HeroSection />

      {/* Trust strip */}
      <TrustStrip />

      {/* Categories */}
      <CategoryGrid />

      {/* Featured Products */}
      <section className="py-20 px-4 sm:px-6 bg-card">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Handpicked</p>
              <h2 className="font-serif text-4xl sm:text-5xl text-foreground">Featured Products</h2>
            </div>
            <Link to="/shop" className="hidden sm:flex items-center gap-1 font-sans text-sm text-primary hover:underline">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="rounded-xl bg-muted animate-pulse aspect-[3/4]" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}

          <div className="text-center mt-10">
            <Button asChild variant="outline" size="lg" className="font-sans border-primary/30">
              <Link to="/shop">View All Products <ArrowRight className="w-4 h-4 ml-2" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Shop by Occasion */}
      <section className="py-20 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">By Occasion</p>
          <h2 className="font-serif text-4xl sm:text-5xl text-foreground">Shop by Occasion</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[
            { label: 'Birthday', icon: '🎂', slug: 'Birthday' },
            { label: 'Wedding', icon: '💍', slug: 'Wedding' },
            { label: 'Bridal Shower', icon: '🌸', slug: 'Bridal+Shower' },
            { label: 'Anniversary', icon: '🥂', slug: 'Anniversary' },
            { label: 'Eid', icon: '🌙', slug: 'Eid' },
            { label: 'Self Care', icon: '✨', slug: 'Self+Care' },
            { label: 'Home Décor', icon: '🏡', slug: 'Home+Décor' },
            { label: 'Thank You', icon: '🙏', slug: 'Thank+You' },
            { label: 'Engagement', icon: '💐', slug: 'Engagement' },
            { label: 'Corporate', icon: '🎁', slug: 'Corporate%2FEvent' },
          ].map((occ) => (
            <Link
              key={occ.slug}
              to={`/shop?occasion=${occ.slug}`}
              className="flex flex-col items-center gap-2 py-5 px-3 rounded-xl border border-border hover:border-primary/40 hover:bg-accent transition-all text-center"
            >
              <span className="text-2xl">{occ.icon}</span>
              <span className="font-sans text-xs font-medium text-foreground">{occ.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Custom Gift Pack banner */}
      <section className="py-20 px-4 sm:px-6" style={{ background: 'linear-gradient(135deg, oklch(0.947 0.022 12) 0%, oklch(0.952 0.034 72) 100%)' }}>
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <div>
            <Package2 className="w-10 h-10 text-primary mb-4" />
            <h2 className="font-serif text-4xl sm:text-5xl text-foreground mb-4">Build Your Own Gift Pack</h2>
            <p className="font-sans text-muted-foreground leading-relaxed mb-6 max-w-md">
              Can't find exactly what you're looking for? Choose your favourite products, tell us the occasion and budget, and we'll create something truly personal.
            </p>
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-sans">
              <Link to="/custom-gift-packs">Request Custom Gift Pack <ArrowRight className="w-4 h-4 ml-2" /></Link>
            </Button>
          </div>
          <div className="hidden md:block">
            <div className="grid grid-cols-2 gap-3">
              {['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400',
                'https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=400',
                'https://images.unsplash.com/photo-1512909006721-3d6018887383?w=400',
                'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=400',
              ].map((src, i) => (
                <div key={i} className={`rounded-xl overflow-hidden ${i === 0 ? 'col-span-2 aspect-video' : 'aspect-square'}`}>
                  <img src={src} alt="Custom gifting" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Bulk Gifting Banner */}
      <section className="py-20 px-4 sm:px-6 bg-card">
        <div className="max-w-7xl mx-auto text-center">
          <Users2 className="w-10 h-10 text-primary mx-auto mb-4" />
          <h2 className="font-serif text-4xl sm:text-5xl text-foreground mb-4">Bulk & Event Gifting</h2>
          <p className="font-sans text-muted-foreground max-w-lg mx-auto mb-8 leading-relaxed">
            Planning a wedding, bridal shower, corporate event, or festive occasion? We handle bulk and event gifting with a personal touch. Custom branding and packaging available.
          </p>
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {['Weddings', 'Engagements', 'Bridal Showers', 'Corporate Events', 'Eid Gifting', 'PR Packages'].map((t) => (
              <span key={t} className="px-3 py-1.5 rounded-full bg-accent border border-border font-sans text-xs text-muted-foreground">
                {t}
              </span>
            ))}
          </div>
          <Button asChild size="lg" variant="outline" className="font-sans border-primary/30">
            <Link to="/bulk-gifting">Submit Bulk Order Request <ArrowRight className="w-4 h-4 ml-2" /></Link>
          </Button>
        </div>
      </section>

      {/* Craft Story */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="grid grid-cols-2 gap-3">
              <img src="https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=500" alt="Candle making" className="rounded-xl aspect-[3/4] object-cover col-span-1 row-span-2" />
              <img src="https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400" alt="Products" className="rounded-xl aspect-square object-cover" />
              <img src="https://images.unsplash.com/photo-1616627561839-074385245ff6?w=400" alt="Tray" className="rounded-xl aspect-square object-cover" />
            </div>
          </div>
          <div className="order-1 md:order-2">
            <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Our Story</p>
            <h2 className="font-serif text-4xl sm:text-5xl text-foreground mb-5">Made to Feel Personal</h2>
            <p className="font-sans text-muted-foreground leading-relaxed mb-4">
              Every Castilla piece begins with a vision: gifting that feels intentional, beautiful, and deeply personal. Our candles are hand-poured in small batches. Our bouquets are sculpted one stem at a time. Our trays are finished by hand.
            </p>
            <p className="font-sans text-muted-foreground leading-relaxed mb-6">
              Soft candles, curated packs, and celebration pieces made to feel personal — for everyone on your list.
            </p>
            <Button asChild variant="outline" className="font-sans border-primary/30">
              <Link to="/about">Learn About Castilla <ArrowRight className="w-4 h-4 ml-2" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Instagram */}
      {instagramItems.length > 0 && (
        <InstagramCarousel items={instagramItems} instagramUrl={instagramUrl} />
      )}

      {/* Delivery & Payment */}
      <section className="py-16 px-4 sm:px-6 bg-card border-y border-border">
        <div className="max-w-7xl mx-auto grid sm:grid-cols-3 gap-8 text-center">
          {[
            { icon: '📦', title: 'How It Works', desc: 'Add to cart, enter your details, choose payment — we confirm your order and keep you updated.' },
            { icon: '🚚', title: 'Delivery', desc: 'We deliver across Pakistan. Charges and timelines are confirmed when your order is processed.' },
            { icon: '💳', title: 'Payment', desc: 'Cash on Delivery, Bank Transfer, Easypaisa, and JazzCash are all accepted.' },
          ].map((item) => (
            <div key={item.title} className="flex flex-col items-center gap-3">
              <span className="text-3xl">{item.icon}</span>
              <h3 className="font-serif text-xl text-foreground">{item.title}</h3>
              <p className="font-sans text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Preview */}
      {faqs.length > 0 && (
        <section className="py-20 px-4 sm:px-6 max-w-7xl mx-auto">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-10">
              <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Got Questions</p>
              <h2 className="font-serif text-4xl sm:text-5xl text-foreground">Frequently Asked</h2>
            </div>
            <div className="space-y-2">
              {faqs.map((faq) => (
                <div key={faq.id} className="border border-border rounded-xl overflow-hidden">
                  <button
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-accent transition-colors"
                    onClick={() => setOpenFaq(openFaq === faq.id ? null : faq.id)}
                  >
                    <span className="font-sans text-sm font-medium text-foreground pr-4">{faq.question}</span>
                    {openFaq === faq.id
                      ? <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    }
                  </button>
                  {openFaq === faq.id && (
                    <div className="px-5 pb-5 font-sans text-sm text-muted-foreground leading-relaxed bg-accent/50">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="text-center mt-6">
              <Link to="/faqs" className="font-sans text-sm text-primary hover:underline">
                View all FAQs <ArrowRight className="inline w-3.5 h-3.5 ml-1" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Final CTA */}
      <section className="py-24 px-4 sm:px-6 text-center" style={{ background: 'linear-gradient(135deg, oklch(0.988 0.009 71) 0%, oklch(0.947 0.022 12) 100%)' }}>
        <h2 className="font-serif text-4xl sm:text-6xl text-foreground mb-5">
          Ready to Find <span style={{ color: 'oklch(0.62 0.085 32)' }}>Something Beautiful?</span>
        </h2>
        <p className="font-sans text-muted-foreground mb-8 max-w-md mx-auto leading-relaxed">
          Add your favourites to cart and place your order in a few simple steps.
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-sans">
            <Link to="/shop">Shop Now <ArrowRight className="w-4 h-4 ml-2" /></Link>
          </Button>
          {whatsapp && (
            <Button asChild size="lg" variant="outline" className="font-sans border-primary/30">
              <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noopener noreferrer">
                WhatsApp Us
              </a>
            </Button>
          )}
        </div>
      </section>
    </div>
  )
}
