import { useEffect, useState } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'
import { getFAQs } from '../lib/api'
import type { FAQ } from '../lib/types'

export function FAQPage() {
  const [faqs, setFaqs] = useState<FAQ[]>([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState<string | null>(null)

  useEffect(() => {
    getFAQs().then(setFaqs).catch(console.error).finally(() => setLoading(false))
  }, [])

  const categories = [...new Set(faqs.map((f) => f.category))]

  return (
    <div>
      <div className="py-20 px-4 sm:px-6 text-center bg-card border-b border-border">
        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Help Centre</p>
        <h1 className="font-serif text-5xl text-foreground mb-4">Frequently Asked Questions</h1>
        <p className="font-sans text-muted-foreground max-w-md mx-auto">
          Everything you need to know about ordering, delivery, customisation, and more.
        </p>
      </div>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-16">
        {loading ? (
          <div className="space-y-2">
            {[...Array(6)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-muted animate-pulse" />)}
          </div>
        ) : (
          categories.map((cat) => (
            <div key={cat} className="mb-10">
              <h2 className="font-serif text-2xl text-foreground mb-4">{cat}</h2>
              <div className="space-y-2">
                {faqs.filter((f) => f.category === cat).map((faq) => (
                  <div key={faq.id} className="border border-border rounded-xl overflow-hidden">
                    <button
                      className="w-full flex items-center justify-between p-5 text-left hover:bg-accent transition-colors"
                      onClick={() => setOpen(open === faq.id ? null : faq.id)}
                    >
                      <span className="font-sans text-sm font-medium text-foreground pr-4">{faq.question}</span>
                      {open === faq.id
                        ? <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      }
                    </button>
                    {open === faq.id && (
                      <div className="px-5 pb-5 font-sans text-sm text-muted-foreground leading-relaxed bg-accent/50">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
        )}

        <div className="mt-10 p-6 rounded-xl bg-accent border border-border text-center">
          <p className="font-sans text-sm font-medium text-foreground mb-2">Still have questions?</p>
          <p className="font-sans text-sm text-muted-foreground mb-4">We're happy to help — reach out via WhatsApp.</p>
          <a
            href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 text-white font-sans text-sm font-medium hover:bg-green-700 transition-colors"
          >
            WhatsApp Us
          </a>
        </div>
      </div>
    </div>
  )
}
