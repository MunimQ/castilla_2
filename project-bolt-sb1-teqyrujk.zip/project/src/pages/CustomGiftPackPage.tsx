import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Package2, CheckCircle2, MessageCircle, Sparkles } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Separator } from '../components/ui/separator'
import { Badge } from '../components/ui/badge'
import { createCustomGiftRequest } from '../lib/api'
import { OCCASIONS } from '../lib/types'
import { cn } from '../lib/utils'

const BUDGET_RANGES = [
  { id: 'under_3000', label: 'Under Rs. 3,000' },
  { id: '3000_6000', label: 'Rs. 3,000 – 6,000' },
  { id: '6000_12000', label: 'Rs. 6,000 – 12,000' },
  { id: 'above_12000', label: 'Above Rs. 12,000' },
  { id: 'flexible', label: 'Flexible / Surprise me' },
]

const PRODUCT_IDEAS = [
  'Scented Candles', 'Flower Bouquet', 'Chocolates', 'Skincare', 'Serving Tray',
  'Jewellery', 'Notebook / Journal', 'Dried Flowers', 'Perfume / Mist', 'Sweet Treats',
]

export function CustomGiftPackPage() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    occasion: '',
    recipient: '',
    budget: '',
    product_preferences: [] as string[],
    message: '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const toggleProduct = (item: string) => {
    setForm((prev) => ({
      ...prev,
      product_preferences: prev.product_preferences.includes(item)
        ? prev.product_preferences.filter((i) => i !== item)
        : [...prev.product_preferences, item],
    }))
  }

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!form.name.trim()) errs.name = 'Name is required'
    if (!form.phone.trim()) errs.phone = 'Phone number is required'
    if (!form.occasion.trim()) errs.occasion = 'Please select an occasion'
    if (!form.budget) errs.budget = 'Please select a budget range'
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }

    setSubmitting(true)
    try {
      await createCustomGiftRequest({
        name: form.name,
        phone: form.phone,
        email: form.email,
        occasion: form.occasion,
        preferred_products: form.product_preferences,
        budget_range: form.budget,
        delivery_city: form.recipient,
        message: form.message,
      })
    } catch {
      // Fallback: continue to success state even if Supabase fails
    }
    setSubmitting(false)
    setSubmitted(true)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  if (submitted) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="font-serif text-3xl text-foreground mb-3">Request Received!</h1>
        <p className="font-sans text-muted-foreground leading-relaxed mb-8">
          Thank you! We'll review your custom gift request and reach out within 24 hours to discuss ideas and confirm details.
        </p>
        <div className="space-y-3">
          <Button asChild size="lg" className="w-full font-sans">
            <a
              href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi Castilla! I just submitted a custom gift pack request for ${form.occasion}. My name is ${form.name}.`)}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Follow Up on WhatsApp
            </a>
          </Button>
          <Button asChild variant="outline" size="lg" className="w-full font-sans">
            <Link to="/shop">Browse Products</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div>
      {/* Hero */}
      <div
        className="py-20 px-4 sm:px-6 text-center"
        style={{ background: 'linear-gradient(135deg, oklch(0.947 0.022 12) 0%, oklch(0.952 0.034 72) 100%)' }}
      >
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <Package2 className="w-7 h-7 text-primary" />
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl text-foreground mb-4">Build Your Custom Gift Pack</h1>
        <p className="font-sans text-muted-foreground max-w-xl mx-auto leading-relaxed mb-6">
          Tell us who it's for, the occasion, and your budget — we'll curate a beautifully packaged gift that feels truly personal.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {['Fully Personalised', 'Luxury Packaging', 'Any Occasion', 'Any Budget'].map((tag) => (
            <Badge key={tag} variant="secondary" className="font-sans text-xs px-3 py-1">
              <Sparkles className="w-3 h-3 mr-1" />
              {tag}
            </Badge>
          ))}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-12">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Contact info */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-5">Your Details</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Full Name *</label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name"
                  className={cn('font-sans', errors.name && 'border-destructive')}
                />
                {errors.name && <p className="font-sans text-xs text-destructive mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Phone Number *</label>
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+92 or 0300..."
                  type="tel"
                  className={cn('font-sans', errors.phone && 'border-destructive')}
                />
                {errors.phone && <p className="font-sans text-xs text-destructive mt-1">{errors.phone}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Email (optional)</label>
                <Input
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="For confirmation"
                  type="email"
                  className="font-sans"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Gift details */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-5">About the Gift</h2>
            <div className="space-y-4">
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Occasion *</label>
                <select
                  value={form.occasion}
                  onChange={(e) => setForm({ ...form, occasion: e.target.value })}
                  className={cn(
                    'w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring',
                    errors.occasion && 'border-destructive'
                  )}
                >
                  <option value="">Select an occasion</option>
                  {OCCASIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                  <option value="Other">Other</option>
                </select>
                {errors.occasion && <p className="font-sans text-xs text-destructive mt-1">{errors.occasion}</p>}
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Who is this gift for?</label>
                <Input
                  value={form.recipient}
                  onChange={(e) => setForm({ ...form, recipient: e.target.value })}
                  placeholder="e.g. My best friend, Mum, Colleague…"
                  className="font-sans"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Budget */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-5">Budget Range *</h2>
            <div className="space-y-2">
              {BUDGET_RANGES.map((b) => (
                <label
                  key={b.id}
                  className={cn(
                    'flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all',
                    form.budget === b.id ? 'border-primary bg-accent' : 'border-border hover:border-primary/40'
                  )}
                >
                  <input
                    type="radio"
                    name="budget"
                    value={b.id}
                    checked={form.budget === b.id}
                    onChange={() => setForm({ ...form, budget: b.id })}
                    className="w-4 h-4 accent-primary"
                  />
                  <span className="font-sans text-sm font-medium text-foreground">{b.label}</span>
                </label>
              ))}
            </div>
            {errors.budget && <p className="font-sans text-xs text-destructive mt-2">{errors.budget}</p>}
          </div>

          <Separator />

          {/* Product preferences */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-2">Product Ideas</h2>
            <p className="font-sans text-sm text-muted-foreground mb-4">Select anything you'd love included (optional).</p>
            <div className="flex flex-wrap gap-2">
              {PRODUCT_IDEAS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggleProduct(item)}
                  className={cn(
                    'px-3 py-1.5 rounded-full border text-sm font-sans transition-all',
                    form.product_preferences.includes(item)
                      ? 'border-primary bg-accent text-foreground font-medium'
                      : 'border-border text-muted-foreground hover:border-primary/40'
                  )}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Message */}
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Additional Notes</label>
            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Colour preferences, allergies, personalisation ideas, delivery date…"
              rows={4}
              className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <p className="font-sans text-xs text-muted-foreground leading-relaxed p-4 rounded-xl bg-accent border border-border">
            We'll review your request and reach out within 24 hours to discuss your pack in detail. No payment is required at this stage.
          </p>

          <Button type="submit" size="lg" disabled={submitting} className="w-full font-sans">
            {submitting ? 'Submitting…' : 'Submit Request'}
            {!submitting && <ArrowRight className="w-4 h-4 ml-2" />}
          </Button>
        </form>

        {/* How it works */}
        <div className="mt-16 pt-12 border-t border-border">
          <h2 className="font-serif text-2xl text-foreground mb-8 text-center">How It Works</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              { step: '1', title: 'Submit Request', desc: 'Fill in this form with occasion, budget, and any product ideas.' },
              { step: '2', title: 'We Curate', desc: 'Our team designs your pack and shares options for your approval.' },
              { step: '3', title: 'We Deliver', desc: 'Once confirmed, we package and deliver your gift across Pakistan.' },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground font-serif text-lg font-semibold flex items-center justify-center mx-auto mb-3">
                  {s.step}
                </div>
                <h3 className="font-serif text-lg text-foreground mb-2">{s.title}</h3>
                <p className="font-sans text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
