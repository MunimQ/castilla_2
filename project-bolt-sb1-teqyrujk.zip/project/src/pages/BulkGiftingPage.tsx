import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Users2, CheckCircle2, MessageCircle } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Separator } from '../components/ui/separator'
import { createBulkRequest } from '../lib/api'
import { cn } from '../lib/utils'

const EVENT_TYPES = [
  'Wedding', 'Engagement', 'Bridal Shower', 'Baby Shower', 'Birthday Party',
  'Corporate Event', 'Eid Gifting', 'PR Package', 'Product Launch', 'Other',
]

const QTY_RANGES = [
  { id: '10_25', label: '10 – 25 packs' },
  { id: '25_50', label: '25 – 50 packs' },
  { id: '50_100', label: '50 – 100 packs' },
  { id: 'above_100', label: '100+ packs' },
]

export function BulkGiftingPage() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    company: '',
    event_type: '',
    quantity: '',
    budget_per_pack: '',
    delivery_date: '',
    branding: false,
    message: '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!form.name.trim()) errs.name = 'Name is required'
    if (!form.phone.trim()) errs.phone = 'Phone number is required'
    if (!form.event_type) errs.event_type = 'Please select an event type'
    if (!form.quantity) errs.quantity = 'Please select a quantity range'
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }

    setSubmitting(true)
    try {
      await createBulkRequest({
        name: form.name,
        phone: form.phone,
        email: form.email,
        company_event_name: form.company,
        event_type: form.event_type,
        budget_range: form.budget_per_pack,
        delivery_cities: '',
        required_date: form.delivery_date || null,
        message: form.message,
        status: 'New',
      })
    } catch {
      // Continue to success state
    }
    setSubmitting(false)
    setSubmitted(true)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  if (submitted) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="font-serif text-3xl text-foreground mb-3">Request Received!</h1>
        <p className="font-sans text-muted-foreground leading-relaxed mb-8">
          Thank you for your bulk gifting inquiry. We'll get back to you within 24–48 hours with a proposal tailored to your event.
        </p>
        <div className="space-y-3">
          <Button asChild size="lg" className="w-full font-sans">
            <a
              href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi Castilla! I just submitted a bulk gifting request for ${form.event_type}. My name is ${form.name}.`)}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Follow Up on WhatsApp
            </a>
          </Button>
          <Button asChild variant="outline" size="lg" className="w-full font-sans">
            <Link to="/shop">Browse Products</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div>
      {/* Hero */}
      <div className="py-20 px-4 sm:px-6 text-center bg-card border-b border-border">
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <Users2 className="w-7 h-7 text-primary" />
        </div>
        <h1 className="font-serif text-4xl sm:text-5xl text-foreground mb-4">Bulk & Event Gifting</h1>
        <p className="font-sans text-muted-foreground max-w-xl mx-auto leading-relaxed mb-8">
          Planning a wedding, corporate event, or festive occasion? We handle bulk gifting with a personal touch — custom branding and luxury packaging available.
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          {['Weddings', 'Engagements', 'Bridal Showers', 'Corporate Events', 'Eid Gifting', 'PR Packages'].map((t) => (
            <span key={t} className="px-3 py-1.5 rounded-full bg-accent border border-border font-sans text-xs text-muted-foreground">
              {t}
            </span>
          ))}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-12">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Contact info */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-5">Contact Details</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Full Name *</label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name"
                  className={cn('font-sans', errors.name && 'border-destructive')}
                />
                {errors.name && <p className="font-sans text-xs text-destructive mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Phone Number *</label>
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+92 or 0300..."
                  type="tel"
                  className={cn('font-sans', errors.phone && 'border-destructive')}
                />
                {errors.phone && <p className="font-sans text-xs text-destructive mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Email (optional)</label>
                <Input
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="For confirmation"
                  type="email"
                  className="font-sans"
                />
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Company / Brand (optional)</label>
                <Input
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  placeholder="Your company name"
                  className="font-sans"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Event details */}
          <div>
            <h2 className="font-serif text-2xl text-foreground mb-5">Event Details</h2>
            <div className="space-y-4">
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Event Type *</label>
                <select
                  value={form.event_type}
                  onChange={(e) => setForm({ ...form, event_type: e.target.value })}
                  className={cn(
                    'w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring',
                    errors.event_type && 'border-destructive'
                  )}
                >
                  <option value="">Select event type</option>
                  {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
                {errors.event_type && <p className="font-sans text-xs text-destructive mt-1">{errors.event_type}</p>}
              </div>

              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-3 block">Quantity Required *</label>
                <div className="grid sm:grid-cols-2 gap-2">
                  {QTY_RANGES.map((q) => (
                    <label
                      key={q.id}
                      className={cn(
                        'flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all',
                        form.quantity === q.id ? 'border-primary bg-accent' : 'border-border hover:border-primary/40'
                      )}
                    >
                      <input
                        type="radio"
                        name="quantity"
                        value={q.id}
                        checked={form.quantity === q.id}
                        onChange={() => setForm({ ...form, quantity: q.id })}
                        className="w-4 h-4 accent-primary"
                      />
                      <span className="font-sans text-sm font-medium text-foreground">{q.label}</span>
                    </label>
                  ))}
                </div>
                {errors.quantity && <p className="font-sans text-xs text-destructive mt-2">{errors.quantity}</p>}
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Budget per Pack (optional)</label>
                  <Input
                    value={form.budget_per_pack}
                    onChange={(e) => setForm({ ...form, budget_per_pack: e.target.value })}
                    placeholder="e.g. Rs. 2,000"
                    className="font-sans"
                  />
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Required Delivery Date (optional)</label>
                  <Input
                    value={form.delivery_date}
                    onChange={(e) => setForm({ ...form, delivery_date: e.target.value })}
                    type="date"
                    className="font-sans"
                  />
                </div>
              </div>

              <label className="flex items-start gap-3 p-4 rounded-xl border border-border cursor-pointer hover:border-primary/40 transition-colors">
                <input
                  type="checkbox"
                  checked={form.branding}
                  onChange={(e) => setForm({ ...form, branding: e.target.checked })}
                  className="w-4 h-4 accent-primary mt-0.5"
                />
                <div>
                  <span className="font-sans text-sm font-medium text-foreground block">I'd like custom branding / logo packaging</span>
                  <span className="font-sans text-xs text-muted-foreground">Printed tags, ribbon, branded boxes, custom message cards</span>
                </div>
              </label>
            </div>
          </div>

          <Separator />

          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Additional Notes</label>
            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Product preferences, colour scheme, delivery location, any other details…"
              rows={4}
              className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <p className="font-sans text-xs text-muted-foreground leading-relaxed p-4 rounded-xl bg-accent border border-border">
            We'll review your request and send a customised proposal within 24–48 hours. No payment is required until you approve the quote.
          </p>

          <Button type="submit" size="lg" disabled={submitting} className="w-full font-sans">
            {submitting ? 'Submitting…' : 'Submit Bulk Request'}
            {!submitting && <ArrowRight className="w-4 h-4 ml-2" />}
          </Button>
        </form>

        {/* Why Castilla */}
        <div className="mt-16 pt-12 border-t border-border">
          <h2 className="font-serif text-2xl text-foreground mb-8 text-center">Why Choose Castilla for Bulk?</h2>
          <div className="grid sm:grid-cols-2 gap-5">
            {[
              { icon: '🎁', title: 'Fully Curated', desc: 'We design each pack with care — products, presentation, and packaging.' },
              { icon: '🏷️', title: 'Custom Branding', desc: 'Logo tags, branded boxes, personalised message cards available.' },
              { icon: '🚚', title: 'Nationwide Delivery', desc: 'Coordinated delivery across Pakistan, even to multiple addresses.' },
              { icon: '💬', title: 'Dedicated Support', desc: 'A single point of contact from inquiry through delivery.' },
            ].map((item) => (
              <div key={item.title} className="flex gap-4 p-4 rounded-xl bg-card border border-border">
                <span className="text-2xl mt-0.5">{item.icon}</span>
                <div>
                  <h3 className="font-sans text-sm font-semibold text-foreground mb-1">{item.title}</h3>
                  <p className="font-sans text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
