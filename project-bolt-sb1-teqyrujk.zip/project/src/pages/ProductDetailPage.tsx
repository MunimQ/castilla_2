import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { ShoppingBag, ArrowRight, Star, Minus, Plus } from 'lucide-react'
import { getProductBySlug, getProducts } from '../lib/api'
import type { Product } from '../lib/types'
import { formatPrice } from '../lib/types'
import { useCart } from '../contexts/CartContext'
import { Button } from '../components/ui/button'
import { Badge } from '../components/ui/badge'
import { Separator } from '../components/ui/separator'
import { ProductCard } from '../components/storefront/ProductCard'
import { cn } from '../lib/utils'

export function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>()
  const [product, setProduct] = useState<Product | null>(null)
  const [related, setRelated] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({})
  const [qty, setQty] = useState(1)
  const { addItem, openCart } = useCart()
  const navigate = useNavigate()

  useEffect(() => {
    if (!slug) return
    setLoading(true)
    Promise.all([getProductBySlug(slug), getProducts()])
      .then(([prod, all]) => {
        if (!prod) { navigate('/shop'); return }
        setProduct(prod)
        // Default first option selections
        const defaults: Record<string, string> = {}
        for (const opt of prod.options as { name: string; values: string[] }[]) {
          if (opt.values.length > 0) defaults[opt.name] = opt.values[0]
        }
        setSelectedOptions(defaults)
        setRelated(all.filter((p) => p.category === prod.category && p.id !== prod.id).slice(0, 4))
        setSelectedImage(0)
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [slug, navigate])

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid md:grid-cols-2 gap-12">
          <div className="aspect-square bg-muted rounded-xl animate-pulse" />
          <div className="space-y-4">
            <div className="h-8 bg-muted rounded animate-pulse w-3/4" />
            <div className="h-6 bg-muted rounded animate-pulse w-1/3" />
            <div className="h-24 bg-muted rounded animate-pulse" />
          </div>
        </div>
      </div>
    )
  }

  if (!product) return null

  const allImages = [product.image_url, ...(product.gallery_images as string[])].filter(Boolean)
  const isCustom = product.price_type === 'custom' || product.price_type === 'quote'
  const options = product.options as { name: string; values: string[] }[]

  const handleAddToCart = () => {
    addItem(product, selectedOptions, qty)
    openCart()
  }

  const handleBuyNow = () => {
    addItem(product, selectedOptions, qty)
    navigate('/checkout')
  }

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-8 font-sans text-sm text-muted-foreground">
          <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
          <span>/</span>
          <Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link>
          <span>/</span>
          <Link to={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-foreground transition-colors">{product.category}</Link>
          <span>/</span>
          <span className="text-foreground truncate">{product.name}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-10 lg:gap-16 mb-20">
          {/* Images */}
          <div>
            {/* Main image */}
            <div className="aspect-square rounded-2xl overflow-hidden bg-accent mb-4 border border-border">
              <img
                src={allImages[selectedImage] || 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=800'}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            {/* Thumbnails */}
            {allImages.length > 1 && (
              <div className="flex gap-2">
                {allImages.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={cn(
                      'w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors flex-shrink-0',
                      i === selectedImage ? 'border-primary' : 'border-border hover:border-primary/50'
                    )}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div>
            <div className="flex items-start justify-between gap-4 mb-2">
              <Link to={`/shop?category=${encodeURIComponent(product.category)}`}>
                <Badge variant="secondary" className="font-sans text-xs">{product.category}</Badge>
              </Link>
              {product.is_bestseller && (
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
              )}
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl text-foreground mb-4 leading-tight">{product.name}</h1>

            {/* Price */}
            <div className="mb-6">
              {isCustom ? (
                <p className="font-sans text-2xl font-semibold text-primary">Custom Quote</p>
              ) : (
                <div className="flex items-baseline gap-3">
                  <span className="font-sans text-2xl font-semibold text-foreground">
                    {product.price_type === 'from' ? 'From ' : ''}{formatPrice(product.price)}
                  </span>
                  {product.compare_at_price && product.compare_at_price > product.price && (
                    <span className="font-sans text-base text-muted-foreground line-through">
                      {formatPrice(product.compare_at_price)}
                    </span>
                  )}
                </div>
              )}
            </div>

            <p className="font-sans text-muted-foreground leading-relaxed mb-6">{product.description}</p>

            {/* Options */}
            {options.length > 0 && (
              <div className="space-y-4 mb-6">
                {options.map((opt) => (
                  <div key={opt.name}>
                    <label className="font-sans text-sm font-medium text-foreground mb-2 block">
                      {opt.name}: <span className="font-normal text-muted-foreground">{selectedOptions[opt.name]}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {opt.values.map((val) => (
                        <button
                          key={val}
                          onClick={() => setSelectedOptions(prev => ({ ...prev, [opt.name]: val }))}
                          className={cn(
                            'px-3 py-1.5 rounded-lg border text-sm font-sans transition-all',
                            selectedOptions[opt.name] === val
                              ? 'border-primary bg-accent text-foreground font-medium'
                              : 'border-border text-muted-foreground hover:border-primary/40'
                          )}
                        >
                          {val}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Quantity */}
            {!isCustom && product.stock_status !== 'out_of_stock' && (
              <div className="mb-6">
                <label className="font-sans text-sm font-medium text-foreground mb-2 block">Quantity</label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    className="w-9 h-9 rounded-lg border border-border flex items-center justify-center hover:bg-accent transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="font-sans text-base w-8 text-center font-medium">{qty}</span>
                  <button
                    onClick={() => setQty(qty + 1)}
                    className="w-9 h-9 rounded-lg border border-border flex items-center justify-center hover:bg-accent transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-wrap gap-3 mb-6">
              {product.stock_status === 'out_of_stock' ? (
                <Button disabled size="lg" className="flex-1 font-sans">Out of Stock</Button>
              ) : isCustom ? (
                <Button asChild size="lg" className="flex-1 bg-primary text-primary-foreground font-sans">
                  <Link to="/custom-gift-packs">Request Custom Quote <ArrowRight className="w-4 h-4 ml-2" /></Link>
                </Button>
              ) : (
                <>
                  <Button
                    size="lg"
                    onClick={handleAddToCart}
                    variant="outline"
                    className="flex-1 font-sans border-primary/30 gap-2"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Add to Cart
                  </Button>
                  <Button
                    size="lg"
                    onClick={handleBuyNow}
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-sans"
                  >
                    Buy Now
                  </Button>
                </>
              )}
            </div>

            {/* Status badges */}
            <div className="flex flex-wrap gap-2 mb-6">
              {product.stock_status === 'in_stock' && (
                <Badge variant="secondary" className="bg-green-50 text-green-700 font-sans text-xs border border-green-200">In Stock</Badge>
              )}
              {product.stock_status === 'low_stock' && (
                <Badge variant="secondary" className="bg-amber-50 text-amber-700 font-sans text-xs border border-amber-200">Low Stock</Badge>
              )}
              {product.stock_status === 'made_to_order' && (
                <Badge variant="secondary" className="font-sans text-xs">Made to Order</Badge>
              )}
              {product.is_customizable && (
                <Badge variant="outline" className="font-sans text-xs">Customizable</Badge>
              )}
              {product.is_bulk_friendly && (
                <Badge variant="outline" className="font-sans text-xs">Bulk Friendly</Badge>
              )}
            </div>

            <Separator className="mb-4" />

            {/* Delivery note */}
            <p className="font-sans text-xs text-muted-foreground leading-relaxed">
              Your order will be confirmed after product availability, delivery details, and payment method are reviewed. Delivery available across Pakistan.
            </p>

            {/* Occasions */}
            {(product.occasions as string[]).length > 0 && (
              <div className="mt-4">
                <p className="font-sans text-xs text-muted-foreground mb-2">Perfect for:</p>
                <div className="flex flex-wrap gap-1.5">
                  {(product.occasions as string[]).map((occ) => (
                    <Link
                      key={occ}
                      to={`/shop?occasion=${encodeURIComponent(occ)}`}
                      className="px-2 py-0.5 rounded-full bg-accent text-xs font-sans text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {occ}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div>
            <Separator className="mb-10" />
            <h2 className="font-serif text-3xl text-foreground mb-8">You Might Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
