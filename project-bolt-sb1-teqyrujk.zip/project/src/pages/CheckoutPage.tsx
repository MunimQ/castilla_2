import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, ChevronLeft, CheckCircle2, MessageCircle } from 'lucide-react'
import { useCart } from '../contexts/CartContext'
import { createOrder } from '../lib/api'
import { formatPrice, generateOrderNumber } from '../lib/types'
import type { CartItem } from '../lib/types'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Separator } from '../components/ui/separator'
import { cn } from '../lib/utils'

const PAYMENT_METHODS = [
  { id: 'cod', label: 'Cash on Delivery' },
  { id: 'bank_transfer', label: 'Bank Transfer' },
  { id: 'easypaisa', label: 'Easypaisa' },
  { id: 'jazzcash', label: 'JazzCash' },
]

interface OrderResult {
  order_number: string
  customer_name: string
  phone: string
  delivery_city: string
  delivery_address: string
  payment_method: string
  items: CartItem[]
  total: number
  notes: string
}

export function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart()
  const navigate = useNavigate()
  const whatsapp = import.meta.env.VITE_WHATSAPP_NUMBER

  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    city: '',
    address: '',
    payment: 'cod',
    notes: '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)
  const [orderResult, setOrderResult] = useState<OrderResult | null>(null)

  if (items.length === 0 && !orderResult) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <p className="font-serif text-2xl text-foreground mb-4">Your cart is empty</p>
        <Button asChild className="font-sans">
          <Link to="/shop">Browse Products</Link>
        </Button>
      </div>
    )
  }

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!form.name.trim()) errs.name = 'Full name is required'
    if (!form.phone.trim()) errs.phone = 'Phone number is required'
    if (!form.city.trim()) errs.city = 'Delivery city is required'
    if (!form.address.trim()) errs.address = 'Delivery address is required'
    if (!form.payment) errs.payment = 'Please select a payment method'
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }

    setSubmitting(true)
    const orderNumber = generateOrderNumber()

    const orderData = {
      order_number: orderNumber,
      customer_name: form.name,
      phone: form.phone,
      email: form.email,
      delivery_city: form.city,
      delivery_address: form.address,
      payment_method: PAYMENT_METHODS.find((p) => p.id === form.payment)?.label || form.payment,
      items,
      subtotal,
      total: subtotal,
      notes: form.notes,
      status: 'New',
      source: 'website',
      admin_notes: '',
    }

    try {
      await createOrder(orderData)
    } catch (err) {
      // Save to localStorage as fallback
      const savedOrders = JSON.parse(localStorage.getItem('castilla_orders') || '[]')
      savedOrders.push({ ...orderData, id: crypto.randomUUID(), created_at: new Date().toISOString(), updated_at: new Date().toISOString() })
      localStorage.setItem('castilla_orders', JSON.stringify(savedOrders))
    }

    setOrderResult({
      order_number: orderNumber,
      customer_name: form.name,
      phone: form.phone,
      delivery_city: form.city,
      delivery_address: form.address,
      payment_method: PAYMENT_METHODS.find((p) => p.id === form.payment)?.label || form.payment,
      items,
      total: subtotal,
      notes: form.notes,
    })

    clearCart()
    setSubmitting(false)
  }

  const buildWhatsAppMessage = (order: OrderResult) => {
    const itemLines = order.items.map((i) =>
      `• ${i.name}${Object.entries(i.selected_options).length ? ` (${Object.entries(i.selected_options).map(([k, v]) => `${k}: ${v}`).join(', ')})` : ''} × ${i.quantity} = ${formatPrice(i.line_total)}`
    ).join('\n')

    const msg = `Hello Castilla, I placed an order from the website.

Order Number: ${order.order_number}

Customer: ${order.customer_name}
Phone: ${order.phone}

Delivery City: ${order.delivery_city}
Address: ${order.delivery_address}

Items:
${itemLines}

Total: ${formatPrice(order.total)}

Payment Method: ${order.payment_method}
${order.notes ? `\nNotes: ${order.notes}` : ''}

Please confirm availability and delivery details.`

    return `https://wa.me/${whatsapp}?text=${encodeURIComponent(msg)}`
  }

  // Order success screen
  if (orderResult) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="font-serif text-3xl text-foreground mb-2">Order Placed!</h1>
          <p className="font-sans text-muted-foreground">Thank you for your order. We'll be in touch shortly to confirm details.</p>
        </div>

        {/* Order summary */}
        <div className="bg-card rounded-xl border border-border p-5 mb-6 space-y-4">
          <div className="flex justify-between">
            <span className="font-sans text-sm text-muted-foreground">Order Number</span>
            <span className="font-sans text-sm font-semibold text-foreground">{orderResult.order_number}</span>
          </div>
          <Separator />
          <div>
            <p className="font-sans text-sm text-muted-foreground mb-2">Items</p>
            {orderResult.items.map((item) => (
              <div key={item.product_id} className="flex justify-between py-1.5 text-sm font-sans">
                <span className="text-foreground flex-1 pr-4">{item.name} × {item.quantity}</span>
                <span className="text-muted-foreground">{formatPrice(item.line_total)}</span>
              </div>
            ))}
          </div>
          <Separator />
          <div className="flex justify-between font-semibold font-sans">
            <span>Total</span>
            <span className="text-primary">{formatPrice(orderResult.total)}</span>
          </div>
          <Separator />
          <div className="space-y-1.5 text-sm font-sans">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Payment</span>
              <span>{orderResult.payment_method}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Delivery to</span>
              <span>{orderResult.delivery_city}</span>
            </div>
          </div>
        </div>

        <p className="font-sans text-xs text-muted-foreground text-center mb-6 leading-relaxed">
          Your order will be confirmed after product availability, delivery details, and payment are reviewed. You'll receive confirmation via phone or WhatsApp.
        </p>

        <div className="space-y-3">
          {whatsapp && (
            <Button asChild size="lg" className="w-full bg-green-600 hover:bg-green-700 text-white font-sans gap-2">
              <a href={buildWhatsAppMessage(orderResult)} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4" />
                Send Order on WhatsApp
              </a>
            </Button>
          )}
          <Button asChild size="lg" variant="outline" className="w-full font-sans">
            <Link to="/shop">Continue Shopping</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
      {/* Back */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 font-sans text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        Back to cart
      </button>

      <div className="grid lg:grid-cols-[1fr_400px] gap-10">
        {/* Form */}
        <div>
          <h1 className="font-serif text-3xl text-foreground mb-8">Checkout</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Customer details */}
            <div>
              <h2 className="font-serif text-xl text-foreground mb-4">Customer Details</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Full Name *</label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your full name"
                    className={cn('font-sans', errors.name && 'border-destructive')}
                  />
                  {errors.name && <p className="font-sans text-xs text-destructive mt-1">{errors.name}</p>}
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Phone Number *</label>
                  <Input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+92 or 0300..."
                    type="tel"
                    className={cn('font-sans', errors.phone && 'border-destructive')}
                  />
                  {errors.phone && <p className="font-sans text-xs text-destructive mt-1">{errors.phone}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Email (optional)</label>
                  <Input
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="for order confirmation"
                    type="email"
                    className="font-sans"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Delivery */}
            <div>
              <h2 className="font-serif text-xl text-foreground mb-4">Delivery Details</h2>
              <div className="space-y-4">
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Delivery City *</label>
                  <Input
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    placeholder="e.g. Karachi, Lahore, Islamabad"
                    className={cn('font-sans', errors.city && 'border-destructive')}
                  />
                  {errors.city && <p className="font-sans text-xs text-destructive mt-1">{errors.city}</p>}
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Full Delivery Address *</label>
                  <textarea
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    placeholder="Street, area, landmark…"
                    rows={3}
                    className={cn(
                      'w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none',
                      errors.address && 'border-destructive'
                    )}
                  />
                  {errors.address && <p className="font-sans text-xs text-destructive mt-1">{errors.address}</p>}
                </div>
                <div>
                  <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Order Notes (optional)</label>
                  <textarea
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                    placeholder="Any special instructions, gift messages…"
                    rows={2}
                    className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Payment */}
            <div>
              <h2 className="font-serif text-xl text-foreground mb-4">Payment Method</h2>
              <div className="space-y-2">
                {PAYMENT_METHODS.map((pm) => (
                  <label
                    key={pm.id}
                    className={cn(
                      'flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all',
                      form.payment === pm.id ? 'border-primary bg-accent' : 'border-border hover:border-primary/40'
                    )}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value={pm.id}
                      checked={form.payment === pm.id}
                      onChange={() => setForm({ ...form, payment: pm.id })}
                      className="w-4 h-4 accent-primary"
                    />
                    <span className="font-sans text-sm font-medium text-foreground">{pm.label}</span>
                  </label>
                ))}
              </div>
              {errors.payment && <p className="font-sans text-xs text-destructive mt-2">{errors.payment}</p>}
            </div>

            <p className="font-sans text-xs text-muted-foreground leading-relaxed p-4 rounded-xl bg-accent border border-border">
              Your order will be confirmed after product availability, delivery details, and payment method are reviewed. No online payment is processed — you'll be contacted to finalise.
            </p>

            <Button
              type="submit"
              size="lg"
              disabled={submitting}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-sans"
            >
              {submitting ? 'Placing Order…' : 'Place Order'}
              {!submitting && <ArrowRight className="w-4 h-4 ml-2" />}
            </Button>
          </form>
        </div>

        {/* Order summary sidebar */}
        <div>
          <div className="sticky top-24 bg-card rounded-2xl border border-border p-6">
            <h2 className="font-serif text-xl text-foreground mb-5">Order Summary</h2>
            <div className="space-y-4 mb-5">
              {items.map((item) => (
                <div key={`${item.product_id}-${JSON.stringify(item.selected_options)}`} className="flex gap-3">
                  <div className="w-14 h-14 rounded-lg overflow-hidden bg-accent flex-shrink-0">
                    <img src={item.image_url || 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=200'} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-sans text-sm font-medium text-foreground line-clamp-2">{item.name}</p>
                    {Object.entries(item.selected_options).length > 0 && (
                      <p className="font-sans text-xs text-muted-foreground">
                        {Object.entries(item.selected_options).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                      </p>
                    )}
                    <div className="flex items-center justify-between mt-1">
                      <span className="font-sans text-xs text-muted-foreground">× {item.quantity}</span>
                      <span className="font-sans text-sm font-medium text-foreground">{formatPrice(item.line_total)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <Separator className="mb-4" />

            <div className="space-y-2">
              <div className="flex justify-between font-sans text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between font-sans text-sm">
                <span className="text-muted-foreground">Delivery</span>
                <span className="text-muted-foreground">Confirmed with order</span>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="flex justify-between font-semibold font-sans">
              <span>Total</span>
              <span className="text-primary text-lg">{formatPrice(subtotal)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
