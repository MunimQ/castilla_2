import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { Button } from '../components/ui/button'

export function AboutPage() {
  return (
    <div>
      {/* Hero */}
      <div
        className="py-24 px-4 sm:px-6 text-center"
        style={{ background: 'linear-gradient(135deg, oklch(0.947 0.022 12) 0%, oklch(0.952 0.034 72) 100%)' }}
      >
        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Our Story</p>
        <h1 className="font-serif text-5xl sm:text-6xl text-foreground mb-5">Made to Feel Personal</h1>
        <p className="font-sans text-muted-foreground max-w-lg mx-auto leading-relaxed">
          Castilla began with one belief: that the best gifts are the ones that feel like they were made just for you.
        </p>
      </div>

      {/* Story section */}
      <section className="py-20 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">The Beginning</p>
            <h2 className="font-serif text-4xl text-foreground mb-5">A Love for Beautiful Things</h2>
            <p className="font-sans text-muted-foreground leading-relaxed mb-4">
              Castilla started in a small studio with a simple vision: create gifts that people genuinely treasure. Not generic, not mass-produced — but beautifully made, thoughtfully designed pieces that carry meaning.
            </p>
            <p className="font-sans text-muted-foreground leading-relaxed mb-4">
              Every candle is hand-poured in small batches. Every bouquet is sculpted one stem at a time. Every tray is finished by hand. We believe that the time and care put into making something shows — and that's what makes a gift feel truly special.
            </p>
            <p className="font-sans text-muted-foreground leading-relaxed">
              Today, Castilla serves customers across Pakistan, from intimate birthday surprises to large-scale wedding and corporate gifting. The commitment hasn't changed: everything is still made with the same love and attention to detail.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <img src="https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=500" alt="Candle making" className="rounded-xl aspect-[3/4] object-cover col-span-1 row-span-2" />
            <img src="https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400" alt="Products" className="rounded-xl aspect-square object-cover" />
            <img src="https://images.unsplash.com/photo-1616627561839-074385245ff6?w=400" alt="Tray" className="rounded-xl aspect-square object-cover" />
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-4 sm:px-6 bg-card border-y border-border">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">What We Stand For</p>
            <h2 className="font-serif text-4xl text-foreground">Our Values</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '✨', title: 'Intentional Design', desc: 'Every product is designed to be beautiful, meaningful, and worthy of giving.' },
              { icon: '🤝', title: 'Personal Service', desc: 'We treat every order — large or small — with individual care and attention.' },
              { icon: '🌿', title: 'Quality Materials', desc: 'We source the finest waxes, florals, and materials to create products that last.' },
              { icon: '🎁', title: 'Gift-Ready Always', desc: 'Every item leaves our studio beautifully packaged and presentation-ready.' },
              { icon: '💬', title: 'Honest Communication', desc: 'We keep you informed at every stage — no surprises, no chasing for updates.' },
              { icon: '🇵🇰', title: 'Proudly Local', desc: 'Made in Pakistan, for Pakistan. We celebrate local craft and artistry.' },
            ].map((v) => (
              <div key={v.title} className="p-6 rounded-xl border border-border hover:border-primary/30 transition-colors">
                <span className="text-3xl mb-4 block">{v.icon}</span>
                <h3 className="font-serif text-xl text-foreground mb-2">{v.title}</h3>
                <p className="font-sans text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What we make */}
      <section className="py-20 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Our Range</p>
          <h2 className="font-serif text-4xl text-foreground">What We Make</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { title: 'Scented Candles', desc: 'Hand-poured in small batches with premium fragrance oils. Every pour is unique.', img: 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=400' },
            { title: 'Candle Bouquets', desc: 'Sculptural arrangements that are art pieces and gifts in one.', img: 'https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=400' },
            { title: 'Concrete Trays', desc: 'Handcrafted concrete serving and vanity trays — functional, beautiful.', img: 'https://images.unsplash.com/photo-1616627561839-074385245ff6?w=400' },
            { title: 'Customized Cakes', desc: 'Made-to-order celebration cakes for every milestone.', img: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400' },
            { title: 'Gift Packs', desc: 'Pre-curated and custom gift sets for any occasion and budget.', img: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400' },
            { title: 'Bubble Candles', desc: 'Playful, aesthetic bubble candles that double as décor.', img: 'https://images.unsplash.com/photo-1512909006721-3d6018887383?w=400' },
          ].map((item) => (
            <div key={item.title} className="group overflow-hidden rounded-2xl border border-border bg-card">
              <div className="aspect-video overflow-hidden">
                <img src={item.img} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-4">
                <h3 className="font-serif text-xl text-foreground mb-1">{item.title}</h3>
                <p className="font-sans text-sm text-muted-foreground">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 text-center" style={{ background: 'linear-gradient(135deg, oklch(0.988 0.009 71) 0%, oklch(0.947 0.022 12) 100%)' }}>
        <h2 className="font-serif text-4xl text-foreground mb-4">Ready to Find Something Beautiful?</h2>
        <p className="font-sans text-muted-foreground mb-8 max-w-md mx-auto">
          Browse our full collection or reach out to discuss a custom creation.
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Button asChild size="lg" className="font-sans">
            <Link to="/shop">Shop Now <ArrowRight className="w-4 h-4 ml-2" /></Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="font-sans border-primary/30">
            <Link to="/custom-gift-packs">Custom Gift Pack</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
