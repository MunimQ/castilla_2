import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { getProducts } from '../lib/api'
import type { Product } from '../lib/types'
import { CATEGORIES } from '../lib/types'
import { ProductCard } from '../components/storefront/ProductCard'
import { Button } from '../components/ui/button'

export function CollectionsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getProducts().then(setProducts).catch(console.error).finally(() => setLoading(false))
  }, [])

  const getByCategory = (cat: string) => products.filter((p) => p.category === cat)

  return (
    <div>
      {/* Hero */}
      <div className="py-16 px-4 sm:px-6 text-center bg-card border-b border-border">
        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Browse by Category</p>
        <h1 className="font-serif text-5xl text-foreground mb-4">Collections</h1>
        <p className="font-sans text-muted-foreground max-w-md mx-auto">
          Explore our handcrafted range, organised by category.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-20">
        {CATEGORIES.map((category) => {
          const items = getByCategory(category)
          if (!loading && items.length === 0) return null
          return (
            <section key={category}>
              <div className="flex items-end justify-between mb-7">
                <div>
                  <h2 className="font-serif text-3xl text-foreground">{category}</h2>
                  {!loading && <p className="font-sans text-sm text-muted-foreground mt-1">{items.length} products</p>}
                </div>
                <Link
                  to={`/shop?category=${encodeURIComponent(category)}`}
                  className="hidden sm:flex items-center gap-1 font-sans text-sm text-primary hover:underline"
                >
                  View All <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              {loading ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[...Array(4)].map((_, i) => <div key={i} className="aspect-[3/4] rounded-xl bg-muted animate-pulse" />)}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                    {items.slice(0, 4).map((p) => <ProductCard key={p.id} product={p} />)}
                  </div>
                  {items.length > 4 && (
                    <div className="text-center mt-6">
                      <Button asChild variant="outline" className="font-sans border-primary/30">
                        <Link to={`/shop?category=${encodeURIComponent(category)}`}>
                          View All {category} <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  )}
                </>
              )}
            </section>
          )
        })}
      </div>
    </div>
  )
}
