import { supabase } from './supabase'
import type { Product, Order, CustomGiftRequest, BulkRequest, InstagramItem, FAQ, SiteSettings } from './types'

// ─── PRODUCTS ────────────────────────────────────────────────────────────────

export async function getProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('display_order', { ascending: true })
  if (error) throw error
  return data || []
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('is_featured', true)
    .order('display_order', { ascending: true })
    .limit(8)
  if (error) throw error
  return data || []
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('slug', slug)
    .maybeSingle()
  if (error) throw error
  return data
}

export async function createProduct(product: Omit<Product, 'id' | 'created_at' | 'updated_at'>): Promise<Product> {
  const { data, error } = await supabase
    .from('products')
    .insert([{ ...product, updated_at: new Date().toISOString() }])
    .select()
    .single()
  if (error) throw error
  return data
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
  const { data, error } = await supabase
    .from('products')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function deleteProduct(id: string): Promise<void> {
  const { error } = await supabase.from('products').delete().eq('id', id)
  if (error) throw error
}

// ─── ORDERS ──────────────────────────────────────────────────────────────────

export async function createOrder(order: Omit<Order, 'id' | 'created_at' | 'updated_at'>): Promise<Order> {
  const { data, error } = await supabase
    .from('orders')
    .insert([{ ...order, updated_at: new Date().toISOString() }])
    .select()
    .single()
  if (error) throw error
  return data
}

export async function getOrders(): Promise<Order[]> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data || []
}

export async function updateOrderStatus(id: string, status: string, admin_notes?: string): Promise<void> {
  const updates: Record<string, unknown> = { status, updated_at: new Date().toISOString() }
  if (admin_notes !== undefined) updates.admin_notes = admin_notes
  const { error } = await supabase.from('orders').update(updates).eq('id', id)
  if (error) throw error
}

// ─── CUSTOM GIFT REQUESTS ─────────────────────────────────────────────────────

export async function createCustomGiftRequest(req: Partial<Omit<CustomGiftRequest, 'id' | 'created_at' | 'updated_at'>>): Promise<CustomGiftRequest> {
  const { data, error } = await supabase
    .from('custom_gift_requests')
    .insert([{ ...req, status: 'New', updated_at: new Date().toISOString() }])
    .select()
    .single()
  if (error) throw error
  return data
}

export async function getCustomGiftRequests(): Promise<CustomGiftRequest[]> {
  const { data, error } = await supabase
    .from('custom_gift_requests')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data || []
}

export async function updateCustomGiftRequestStatus(id: string, status: string, admin_notes?: string): Promise<void> {
  const updates: Record<string, unknown> = { status, updated_at: new Date().toISOString() }
  if (admin_notes !== undefined) updates.admin_notes = admin_notes
  const { error } = await supabase.from('custom_gift_requests').update(updates).eq('id', id)
  if (error) throw error
}

// ─── BULK REQUESTS ────────────────────────────────────────────────────────────

export async function createBulkRequest(req: Partial<Omit<BulkRequest, 'id' | 'created_at' | 'updated_at'>>): Promise<BulkRequest> {
  const { data, error } = await supabase
    .from('bulk_requests')
    .insert([{ ...req, status: 'New', updated_at: new Date().toISOString() }])
    .select()
    .single()
  if (error) throw error
  return data
}

export async function getBulkRequests(): Promise<BulkRequest[]> {
  const { data, error } = await supabase
    .from('bulk_requests')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data || []
}

export async function updateBulkRequestStatus(id: string, status: string, admin_notes?: string): Promise<void> {
  const updates: Record<string, unknown> = { status, updated_at: new Date().toISOString() }
  if (admin_notes !== undefined) updates.admin_notes = admin_notes
  const { error } = await supabase.from('bulk_requests').update(updates).eq('id', id)
  if (error) throw error
}

// ─── SITE SETTINGS ────────────────────────────────────────────────────────────

export async function getSiteSettings(): Promise<SiteSettings> {
  const { data, error } = await supabase.from('site_settings').select('*')
  if (error) throw error
  const settings: SiteSettings = {}
  for (const row of data || []) {
    ;(settings as Record<string, unknown>)[row.key] = row.value
  }
  return settings
}

export async function upsertSiteSetting(key: string, value: unknown): Promise<void> {
  const { error } = await supabase
    .from('site_settings')
    .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: 'key' })
  if (error) throw error
}

// ─── INSTAGRAM ITEMS ──────────────────────────────────────────────────────────

export async function getInstagramItems(): Promise<InstagramItem[]> {
  const { data, error } = await supabase
    .from('instagram_items')
    .select('*')
    .eq('is_active', true)
    .order('display_order', { ascending: true })
  if (error) throw error
  return data || []
}

export async function getAllInstagramItems(): Promise<InstagramItem[]> {
  const { data, error } = await supabase
    .from('instagram_items')
    .select('*')
    .order('display_order', { ascending: true })
  if (error) throw error
  return data || []
}

export async function upsertInstagramItem(item: Partial<InstagramItem> & { id?: string }): Promise<InstagramItem> {
  const payload = { ...item, updated_at: new Date().toISOString() }
  if (item.id) {
    const { data, error } = await supabase.from('instagram_items').update(payload).eq('id', item.id).select().single()
    if (error) throw error
    return data
  } else {
    const { data, error } = await supabase.from('instagram_items').insert([payload]).select().single()
    if (error) throw error
    return data
  }
}

export async function deleteInstagramItem(id: string): Promise<void> {
  const { error } = await supabase.from('instagram_items').delete().eq('id', id)
  if (error) throw error
}

// ─── FAQS ─────────────────────────────────────────────────────────────────────

export async function getFAQs(): Promise<FAQ[]> {
  const { data, error } = await supabase
    .from('faqs')
    .select('*')
    .eq('is_active', true)
    .order('display_order', { ascending: true })
  if (error) throw error
  return data || []
}

export async function getAllFAQs(): Promise<FAQ[]> {
  const { data, error } = await supabase
    .from('faqs')
    .select('*')
    .order('display_order', { ascending: true })
  if (error) throw error
  return data || []
}

export async function upsertFAQ(faq: Partial<FAQ> & { id?: string }): Promise<FAQ> {
  const payload = { ...faq, updated_at: new Date().toISOString() }
  if (faq.id) {
    const { data, error } = await supabase.from('faqs').update(payload).eq('id', faq.id).select().single()
    if (error) throw error
    return data
  } else {
    const { data, error } = await supabase.from('faqs').insert([payload]).select().single()
    if (error) throw error
    return data
  }
}

export async function deleteFAQ(id: string): Promise<void> {
  const { error } = await supabase.from('faqs').delete().eq('id', id)
  if (error) throw error
}
