export interface Product {
  id: string
  slug: string
  name: string
  category: string
  short_description: string
  description: string
  price: number
  price_type: 'fixed' | 'from' | 'custom' | 'quote'
  compare_at_price?: number | null
  image_url: string
  gallery_images: string[]
  tags: string[]
  occasions: string[]
  options: ProductOption[]
  stock_status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'made_to_order'
  quantity_available?: number | null
  is_featured: boolean
  is_bestseller: boolean
  is_customizable: boolean
  is_bulk_friendly: boolean
  display_order: number
  seo_title: string
  seo_description: string
  created_at: string
  updated_at: string
}

export interface ProductOption {
  name: string
  values: string[]
}

export interface CartItem {
  product_id: string
  slug: string
  name: string
  image_url: string
  price: number
  price_type: 'fixed' | 'from' | 'custom' | 'quote'
  category: string
  selected_options: Record<string, string>
  quantity: number
  line_total: number
}

export interface Order {
  id: string
  order_number: string
  customer_name: string
  phone: string
  email: string
  delivery_city: string
  delivery_address: string
  payment_method: string
  items: CartItem[]
  subtotal: number
  total: number
  notes: string
  status: string
  source: string
  admin_notes: string
  created_at: string
  updated_at: string
}

export interface CustomGiftRequest {
  id: string
  name: string
  phone: string
  email: string
  occasion: string
  preferred_products: string[]
  budget_range: string
  delivery_city: string
  required_date?: string | null
  message: string
  status: string
  admin_notes: string
  created_at: string
  updated_at: string
}

export interface BulkRequest {
  id: string
  name: string
  company_event_name: string
  phone: string
  email: string
  event_type: string
  estimated_quantity: number
  delivery_cities: string
  preferred_products: string[]
  required_date?: string | null
  budget_range: string
  message: string
  status: string
  admin_notes: string
  created_at: string
  updated_at: string
}

export interface InstagramItem {
  id: string
  image_url: string
  caption: string
  link: string
  display_order: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface FAQ {
  id: string
  question: string
  answer: string
  category: string
  display_order: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface SiteSettings {
  announcement_bar?: { text: string; is_active: boolean }
  hero?: { headline: string; subheadline: string; trust_line: string }
  contact?: { phone: string; whatsapp: string; instagram_url: string; email: string; address: string }
  delivery?: { note: string; cities: string[] }
  payment_methods?: { methods: PaymentMethod[] }
  seo?: { site_title: string; meta_description: string; og_image: string }
  footer?: { tagline: string; copyright: string }
}

export interface PaymentMethod {
  id: string
  name: string
  is_active: boolean
}

export const CATEGORIES = [
  'Scented Candles',
  'Candle Bouquets',
  'Concrete Trays',
  'Customized Cakes',
  'Bubble Candles',
  'Pre-Made Gift Packs',
  'Custom Gift Packs',
] as const

export const OCCASIONS = [
  'Birthday',
  'Wedding',
  'Engagement',
  'Anniversary',
  'Bridal Shower',
  'Self Care',
  'Home Décor',
  'Eid',
  'Thank You',
  'Corporate/Event',
] as const

export const ORDER_STATUSES = [
  'New',
  'Contacted',
  'Confirmed',
  'Preparing',
  'Ready for Dispatch',
  'Completed',
  'Cancelled',
] as const

export const formatPrice = (price: number): string => {
  return `Rs. ${price.toLocaleString('en-PK')}`
}

export const generateOrderNumber = (): string => {
  const timestamp = Date.now().toString().slice(-5)
  const random = Math.floor(Math.random() * 100).toString().padStart(2, '0')
  return `CAS-${timestamp}${random}`
}
