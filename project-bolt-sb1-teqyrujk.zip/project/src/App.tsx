import { BrowserRouter, Routes, Route, Outlet } from 'react-router-dom'
import { CartProvider } from './contexts/CartContext'
import { AdminProvider } from './contexts/AdminContext'
import { Navbar } from './components/layout/Navbar'
import { Footer } from './components/layout/Footer'
import { AnnouncementBar } from './components/layout/AnnouncementBar'
import { CartDrawer } from './components/cart/CartDrawer'
import { AdminLayout } from './components/admin/AdminLayout'
import { AdminLoginPage } from './components/admin/AdminLoginPage'
import { AdminDashboard } from './components/admin/AdminDashboard'
import { AdminProductsPage } from './components/admin/AdminProductsPage'
import { AdminAddEditProduct } from './components/admin/AdminAddEditProduct'
import { AdminOrdersPage } from './components/admin/AdminOrdersPage'
import { AdminCustomRequestsPage } from './components/admin/AdminCustomRequestsPage'
import { AdminBulkRequestsPage } from './components/admin/AdminBulkRequestsPage'
import { AdminInstagramPage } from './components/admin/AdminInstagramPage'
import { AdminFAQsPage } from './components/admin/AdminFAQsPage'
import { AdminSettingsPage } from './components/admin/AdminSettingsPage'
import { HomePage } from './pages/HomePage'
import { ShopPage } from './pages/ShopPage'
import { ProductDetailPage } from './pages/ProductDetailPage'
import { CheckoutPage } from './pages/CheckoutPage'
import { CustomGiftPackPage } from './pages/CustomGiftPackPage'
import { BulkGiftingPage } from './pages/BulkGiftingPage'
import { CollectionsPage } from './pages/CollectionsPage'
import { AboutPage } from './pages/AboutPage'
import { ContactPage } from './pages/ContactPage'
import { FAQPage } from './pages/FAQPage'

function StorefrontLayout() {
  return (
    <>
      <AnnouncementBar />
      <Navbar />
      <CartDrawer />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  )
}

function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <AdminProvider>
          <Routes>
            {/* Storefront */}
            <Route element={<StorefrontLayout />}>
              <Route path="/" element={<HomePage />} />
              <Route path="/shop" element={<ShopPage />} />
              <Route path="/shop/:slug" element={<ProductDetailPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/collections" element={<CollectionsPage />} />
              <Route path="/custom-gift-packs" element={<CustomGiftPackPage />} />
              <Route path="/bulk-gifting" element={<BulkGiftingPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/faqs" element={<FAQPage />} />
            </Route>

            {/* Admin */}
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="products" element={<AdminProductsPage />} />
              <Route path="products/:id" element={<AdminAddEditProduct />} />
              <Route path="orders" element={<AdminOrdersPage />} />
              <Route path="custom-requests" element={<AdminCustomRequestsPage />} />
              <Route path="bulk-requests" element={<AdminBulkRequestsPage />} />
              <Route path="instagram" element={<AdminInstagramPage />} />
              <Route path="faqs" element={<AdminFAQsPage />} />
              <Route path="settings" element={<AdminSettingsPage />} />
            </Route>
          </Routes>
        </AdminProvider>
      </CartProvider>
    </BrowserRouter>
  )
}

export default App
