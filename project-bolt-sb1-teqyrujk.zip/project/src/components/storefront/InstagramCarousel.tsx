import { useRef } from 'react'
import { ChevronLeft, ChevronRight, Camera } from 'lucide-react'
import type { InstagramItem } from '../../lib/types'

interface InstagramCarouselProps {
  items: InstagramItem[]
  instagramUrl?: string
}

export function InstagramCarousel({ items, instagramUrl }: InstagramCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (dir: 'left' | 'right') => {
    const el = scrollRef.current
    if (!el) return
    el.scrollBy({ left: dir === 'left' ? -300 : 300, behavior: 'smooth' })
  }

  if (!items.length) return null

  return (
    <section className="py-20" style={{ background: 'oklch(0.984 0.01 68)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Follow Our Journey</p>
            <h2 className="font-serif text-4xl sm:text-5xl text-foreground">From Our Instagram</h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => scroll('left')}
              className="w-9 h-9 rounded-full border border-border flex items-center justify-center hover:bg-accent transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-9 h-9 rounded-full border border-border flex items-center justify-center hover:bg-accent transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Carousel */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {items.map((item) => (
            <a
              key={item.id}
              href={item.link || instagramUrl || '#'}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex-shrink-0 w-64 sm:w-72 rounded-xl overflow-hidden border border-border hover:border-primary/40 transition-all hover:shadow-md"
            >
              <div className="aspect-square overflow-hidden bg-accent">
                <img
                  src={item.image_url}
                  alt={item.caption || 'Instagram post'}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              {item.caption && (
                <div className="p-3">
                  <p className="font-sans text-xs text-muted-foreground leading-relaxed line-clamp-2">{item.caption}</p>
                </div>
              )}
            </a>
          ))}
        </div>

        {/* Follow link */}
        {instagramUrl && (
          <div className="mt-8 text-center">
            <a
              href={instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-primary/30 text-primary font-sans text-sm font-medium hover:bg-accent transition-colors"
            >
              <Camera className="w-4 h-4" />
              Follow us on Instagram
            </a>
          </div>
        )}
      </div>
    </section>
  )
}
