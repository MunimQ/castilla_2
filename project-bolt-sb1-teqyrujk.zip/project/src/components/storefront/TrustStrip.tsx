import { Shield, Truck, Star, HeartHandshake } from 'lucide-react'

const trustItems = [
  { icon: HeartHandshake, label: 'Handcrafted', desc: 'Made with care' },
  { icon: Star, label: 'Premium Quality', desc: 'Luxury materials' },
  { icon: Truck, label: 'Nationwide Delivery', desc: 'Across Pakistan' },
  { icon: Shield, label: 'Secure Orders', desc: 'Safe & confirmed' },
]

export function TrustStrip() {
  return (
    <div className="border-y border-border bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {trustItems.map(({ icon: Icon, label, desc }) => (
            <div key={label} className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="font-sans text-xs font-semibold text-foreground">{label}</p>
                <p className="font-sans text-xs text-muted-foreground">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
