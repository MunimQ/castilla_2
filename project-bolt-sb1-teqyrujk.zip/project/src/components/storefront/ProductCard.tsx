import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ShoppingBag, Eye, Star, Heart } from 'lucide-react'
import type { Product } from '../../lib/types'
import { formatPrice } from '../../lib/types'
import { useCart } from '../../contexts/CartContext'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { cn } from '../../lib/utils'

interface ProductCardProps {
  product: Product
  className?: string
}

export function ProductCard({ product, className }: ProductCardProps) {
  const { addItem, openCart } = useCart()
  const navigate = useNavigate()
  const [imageLoaded, setImageLoaded] = useState(false)
  const [wishlist, setWishlist] = useState(false)

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (product.price_type === 'custom' || product.price_type === 'quote') {
      navigate(`/products/${product.slug}`)
      return
    }
    addItem(product)
    openCart()
  }

  const isOutOfStock = product.stock_status === 'out_of_stock'
  const isMadeToOrder = product.stock_status === 'made_to_order'

  return (
    <div className={cn(
      'group bg-card rounded-xl overflow-hidden border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:-translate-y-1',
      className
    )}>
      {/* Image */}
      <Link to={`/products/${product.slug}`} className="block relative overflow-hidden aspect-square">
        {/* Skeleton */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-accent animate-pulse" />
        )}
        <img
          src={product.image_url || 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=600'}
          alt={product.name}
          className={cn(
            'w-full h-full object-cover transition-transform duration-500 group-hover:scale-105',
            imageLoaded ? 'opacity-100' : 'opacity-0'
          )}
          onLoad={() => setImageLoaded(true)}
        />

        {/* Overlays */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.is_bestseller && (
            <Badge className="bg-primary text-primary-foreground text-xs font-sans">
              Bestseller
            </Badge>
          )}
          {product.compare_at_price && product.compare_at_price > product.price && (
            <Badge variant="secondary" className="text-xs font-sans bg-champagne-wash text-secondary-foreground">
              Sale
            </Badge>
          )}
          {isMadeToOrder && (
            <Badge variant="outline" className="text-xs font-sans bg-background/80">
              Made to Order
            </Badge>
          )}
          {isOutOfStock && (
            <Badge variant="secondary" className="text-xs font-sans bg-muted text-muted-foreground">
              Out of Stock
            </Badge>
          )}
        </div>

        {/* Wishlist */}
        <button
          onClick={(e) => { e.preventDefault(); setWishlist(!wishlist) }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-background"
        >
          <Heart className={cn('w-4 h-4', wishlist ? 'fill-primary text-primary' : 'text-muted-foreground')} />
        </button>

        {/* Quick actions overlay */}
        <div className="absolute bottom-0 left-0 right-0 flex gap-2 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <Link
            to={`/products/${product.slug}`}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-background/90 backdrop-blur-sm text-xs font-sans font-medium text-foreground hover:bg-background transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </Link>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <p className="font-sans text-xs text-muted-foreground mb-1 uppercase tracking-wide">{product.category}</p>
        <Link to={`/products/${product.slug}`}>
          <h3 className="font-serif text-base text-foreground leading-snug mb-2 hover:text-primary transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>

        {product.short_description && (
          <p className="font-sans text-xs text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
            {product.short_description}
          </p>
        )}

        <div className="flex items-center justify-between gap-2">
          {/* Price */}
          <div>
            {product.price_type === 'custom' || product.price_type === 'quote' ? (
              <span className="font-sans text-sm text-primary font-medium">Custom Quote</span>
            ) : (
              <div className="flex items-baseline gap-1.5">
                <span className="font-sans font-semibold text-foreground">
                  {product.price_type === 'from' ? 'From ' : ''}{formatPrice(product.price)}
                </span>
                {product.compare_at_price && product.compare_at_price > product.price && (
                  <span className="font-sans text-xs text-muted-foreground line-through">
                    {formatPrice(product.compare_at_price)}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Add to Cart */}
          {!isOutOfStock ? (
            <Button
              size="sm"
              onClick={handleAddToCart}
              disabled={product.price_type === 'custom' || product.price_type === 'quote'}
              className={cn(
                'text-xs font-sans gap-1.5',
                product.price_type === 'custom' || product.price_type === 'quote'
                  ? 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  : 'bg-primary text-primary-foreground hover:bg-primary/90'
              )}
            >
              {product.price_type === 'custom' || product.price_type === 'quote' ? (
                'View Details'
              ) : (
                <>
                  <ShoppingBag className="w-3 h-3" />
                  Add to Cart
                </>
              )}
            </Button>
          ) : (
            <Button size="sm" variant="outline" disabled className="text-xs font-sans">
              Out of Stock
            </Button>
          )}
        </div>

        {/* Rating stars decorative */}
        {product.is_bestseller && (
          <div className="flex items-center gap-0.5 mt-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3 h-3 fill-candle-amber text-candle-amber" style={{ color: 'oklch(0.785 0.127 68)' }} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
