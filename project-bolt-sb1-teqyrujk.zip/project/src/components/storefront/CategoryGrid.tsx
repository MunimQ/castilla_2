import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

const categories = [
  {
    name: 'Scented Candles',
    description: 'Hand-poured soy candles in signature scents',
    image: 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=600',
    color: 'oklch(0.947 0.022 12)',
    slug: 'Scented+Candles',
  },
  {
    name: 'Candle Bouquets',
    description: 'Sculptural bouquets of handcrafted candles',
    image: 'https://images.unsplash.com/photo-1563241527-3004b7be0b60?w=600',
    color: 'oklch(0.952 0.034 72)',
    slug: 'Candle+Bouquets',
  },
  {
    name: 'Concrete Trays',
    description: 'Hand-finished concrete trays for styling',
    image: 'https://images.unsplash.com/photo-1616627561839-074385245ff6?w=600',
    color: 'oklch(0.968 0.018 65)',
    slug: 'Concrete+Trays',
  },
  {
    name: 'Customized Cakes',
    description: 'Freshly baked, beautifully decorated to order',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600',
    color: 'oklch(0.960 0.025 55)',
    slug: 'Customized+Cakes',
  },
  {
    name: 'Bubble Candles',
    description: 'Sculptural bubble candles in tonal sets',
    image: 'https://images.unsplash.com/photo-1531259922257-f50440d6a2fb?w=600',
    color: 'oklch(0.955 0.018 20)',
    slug: 'Bubble+Candles',
  },
  {
    name: 'Gift Packs',
    description: 'Curated packs ready for every occasion',
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600',
    color: 'oklch(0.948 0.03 12)',
    slug: 'Pre-Made+Gift+Packs',
  },
]

export function CategoryGrid() {
  return (
    <section className="py-20 px-4 sm:px-6 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-3">Our Collections</p>
        <h2 className="font-serif text-4xl sm:text-5xl text-foreground">Shop by Category</h2>
        <p className="font-sans text-muted-foreground mt-3 max-w-md mx-auto">
          Choose a ready gift or build one around your occasion.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
        {categories.map((cat) => (
          <Link
            key={cat.slug}
            to={`/shop?category=${cat.slug}`}
            className="group relative overflow-hidden rounded-xl border border-border hover:border-primary/40 transition-all duration-300 hover:shadow-lg"
            style={{ background: cat.color }}
          >
            {/* Image */}
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-80 mix-blend-multiply"
              />
            </div>

            {/* Text */}
            <div className="p-4 pb-5">
              <h3 className="font-serif text-lg text-foreground leading-tight mb-1">{cat.name}</h3>
              <p className="font-sans text-xs text-muted-foreground leading-relaxed">{cat.description}</p>
              <div className="flex items-center gap-1 mt-3 text-primary font-sans text-xs font-medium">
                Shop Now
                <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
