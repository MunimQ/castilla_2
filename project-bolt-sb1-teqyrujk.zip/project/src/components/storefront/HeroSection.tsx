import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Sparkles, Package, Truck } from 'lucide-react'
import { Button } from '../ui/button'

export function HeroSection() {
  const floatingRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = floatingRef.current
    if (!el) return
    let frame: number
    let t = 0
    const animate = () => {
      t += 0.015
      el.style.transform = `translateY(${Math.sin(t) * 10}px) rotate(${Math.sin(t * 0.7) * 3}deg)`
      frame = requestAnimationFrame(animate)
    }
    animate()
    return () => cancelAnimationFrame(frame)
  }, [])

  return (
    <section className="relative overflow-hidden min-h-[88vh] flex items-center"
      style={{
        background: 'linear-gradient(135deg, oklch(0.988 0.009 71) 0%, oklch(0.967 0.022 22) 45%, oklch(0.952 0.034 72) 100%)'
      }}
    >
      {/* Decorative background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-30"
          style={{ background: 'radial-gradient(circle, oklch(0.947 0.022 12) 0%, transparent 70%)' }} />
        <div className="absolute bottom-0 -left-20 w-80 h-80 rounded-full opacity-20"
          style={{ background: 'radial-gradient(circle, oklch(0.952 0.034 72) 0%, transparent 70%)' }} />
        <div className="absolute top-1/2 left-1/3 w-64 h-64 rounded-full opacity-15"
          style={{ background: 'radial-gradient(circle, oklch(0.62 0.085 32 / 0.3) 0%, transparent 70%)' }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full py-16 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        {/* Text content */}
        <div className="max-w-xl">
          {/* Tag line */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent border border-primary/20 mb-6">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="font-sans text-xs text-primary font-medium tracking-wide">
              Handcrafted Gifting · Karachi & Nationwide
            </span>
          </div>

          <h1 className="font-serif text-5xl sm:text-6xl lg:text-6xl xl:text-7xl text-foreground leading-tight mb-6" style={{ letterSpacing: '-0.02em' }}>
            Beautiful Gifts,<br />
            <span style={{ color: 'oklch(0.62 0.085 32)' }}>Thoughtfully</span><br />
            Made
          </h1>

          <p className="font-sans text-base sm:text-lg text-muted-foreground leading-relaxed mb-8 max-w-md">
            Shop candles, candle bouquets, concrete trays, cakes, bubble candles, and curated gift packs — designed for warm homes, thoughtful gestures, and elegant celebrations.
          </p>

          {/* Trust line */}
          <p className="font-sans text-xs text-muted-foreground mb-8 tracking-wide uppercase">
            Handcrafted gifting · Custom packs · Nationwide delivery
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-3">
            <Button
              asChild
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-sans shadow-lg"
            >
              <Link to="/shop">
                Shop Now <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="font-sans border-primary/30 hover:bg-accent"
            >
              <Link to="/custom-gift-packs">
                <Package className="w-4 h-4 mr-2 text-primary" />
                Build a Gift Pack
              </Link>
            </Button>
            <Button
              asChild
              variant="ghost"
              size="lg"
              className="font-sans hover:bg-accent"
            >
              <Link to="/bulk-gifting">
                Bulk Gifting
              </Link>
            </Button>
          </div>
        </div>

        {/* Visual — decorative candle scene */}
        <div className="hidden lg:flex items-center justify-center relative">
          <div ref={floatingRef} className="relative">
            {/* Main product scene */}
            <div className="relative w-80 h-80">
              {/* Background glow */}
              <div className="absolute inset-0 rounded-full opacity-40"
                style={{ background: 'radial-gradient(circle at 50% 60%, oklch(0.62 0.085 32 / 0.35) 0%, transparent 65%)' }}
              />

              {/* Tray base */}
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-52 h-12 rounded-xl"
                style={{
                  background: 'linear-gradient(135deg, oklch(0.75 0.035 55) 0%, oklch(0.65 0.04 50) 100%)',
                  boxShadow: '0 8px 24px oklch(0.5 0.04 40 / 0.4), inset 0 1px 0 oklch(0.88 0.02 60)'
                }}
              />

              {/* Tall candle 1 */}
              <div className="absolute left-16 bottom-16" style={{ width: 36, height: 100 }}>
                <div className="w-full rounded-sm"
                  style={{
                    height: '100%',
                    background: 'linear-gradient(135deg, oklch(0.95 0.025 15) 0%, oklch(0.87 0.04 20) 60%, oklch(0.8 0.05 25) 100%)',
                    boxShadow: '4px 0 12px oklch(0.62 0.085 32 / 0.2), inset -3px 0 8px oklch(0.75 0.04 20 / 0.3)'
                  }}
                />
                {/* Flame */}
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="w-2.5 h-5 rounded-full animate-pulse"
                    style={{
                      background: 'linear-gradient(to top, oklch(0.785 0.127 68), oklch(0.93 0.1 80), oklch(0.97 0.05 90))',
                      filter: 'blur(1px)',
                      boxShadow: '0 0 10px oklch(0.785 0.127 68 / 0.8), 0 0 20px oklch(0.785 0.127 68 / 0.4)'
                    }}
                  />
                </div>
              </div>

              {/* Shorter candle 2 */}
              <div className="absolute left-1/2 -translate-x-1/2 bottom-16" style={{ width: 44, height: 72 }}>
                <div className="w-full rounded-sm"
                  style={{
                    height: '100%',
                    background: 'linear-gradient(135deg, oklch(0.96 0.02 50) 0%, oklch(0.88 0.04 45) 100%)',
                    boxShadow: '4px 0 12px oklch(0.62 0.085 32 / 0.15), inset -3px 0 8px oklch(0.8 0.03 45 / 0.3)'
                  }}
                />
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="w-3 h-6 rounded-full animate-pulse"
                    style={{
                      animationDelay: '0.3s',
                      background: 'linear-gradient(to top, oklch(0.785 0.127 68), oklch(0.93 0.1 80), oklch(0.97 0.05 90))',
                      filter: 'blur(1px)',
                      boxShadow: '0 0 12px oklch(0.785 0.127 68 / 0.8)'
                    }}
                  />
                </div>
              </div>

              {/* Sphere decoration */}
              <div className="absolute right-12 bottom-20 w-12 h-12 rounded-full"
                style={{
                  background: 'linear-gradient(135deg, oklch(0.94 0.04 12) 0%, oklch(0.82 0.06 18) 100%)',
                  boxShadow: '2px 4px 12px oklch(0.62 0.085 32 / 0.25), inset -3px -3px 8px oklch(0.65 0.07 18 / 0.3)'
                }}
              />

              {/* Petal accents */}
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-3 h-3 rounded-full opacity-60"
                  style={{
                    background: 'oklch(0.87 0.055 12)',
                    left: `${30 + i * 14}%`,
                    top: `${20 + Math.sin(i * 1.2) * 15}%`,
                    transform: `rotate(${i * 36}deg) scale(${0.6 + i * 0.1})`
                  }}
                />
              ))}
            </div>
          </div>

          {/* Floating stats cards */}
          <div className="absolute top-4 right-0 bg-background/90 backdrop-blur-sm rounded-xl px-4 py-3 shadow-lg border border-border">
            <p className="font-sans text-xs text-muted-foreground">Premium Gifting</p>
            <p className="font-sans text-sm font-semibold text-foreground mt-0.5">Nationwide Delivery</p>
          </div>

          <div className="absolute bottom-4 left-0 bg-background/90 backdrop-blur-sm rounded-xl px-4 py-3 shadow-lg border border-border flex items-center gap-2">
            <Truck className="w-4 h-4 text-primary flex-shrink-0" />
            <div>
              <p className="font-sans text-xs text-muted-foreground">Fast Delivery</p>
              <p className="font-sans text-sm font-semibold text-foreground">Across Pakistan</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
