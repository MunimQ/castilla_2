import { useEffect, useState } from 'react'
import { Plus, Pencil, Trash2 } from 'lucide-react'
import { getAllFAQs, upsertFAQ, deleteFAQ } from '../../lib/api'
import type { FAQ } from '../../lib/types'
import { Button } from '../ui/button'
import { Input } from '../ui/input'

type FormState = { question: string; answer: string; category: string; display_order: number; is_active: boolean }

const emptyForm: FormState = { question: '', answer: '', category: 'General', display_order: 0, is_active: true }

export function AdminFAQsPage() {
  const [faqs, setFaqs] = useState<FAQ[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [showForm, setShowForm] = useState(false)

  const load = () => {
    setLoading(true)
    getAllFAQs().then(setFaqs).catch(console.error).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleEdit = (faq: FAQ) => {
    setEditing(faq.id)
    setForm({ question: faq.question, answer: faq.answer, category: faq.category, display_order: faq.display_order, is_active: faq.is_active })
    setShowForm(true)
  }

  const handleNew = () => {
    setEditing(null)
    setForm({ ...emptyForm, display_order: faqs.length + 1 })
    setShowForm(true)
  }

  const handleSave = async () => {
    if (!form.question.trim() || !form.answer.trim()) return
    setSaving(true)
    try {
      await upsertFAQ(editing ? { id: editing, ...form } : form)
      load()
      setShowForm(false)
      setEditing(null)
    } catch {
      alert('Failed to save.')
    }
    setSaving(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this FAQ?')) return
    try {
      await deleteFAQ(id)
      setFaqs((prev) => prev.filter((f) => f.id !== id))
    } catch {
      alert('Failed to delete.')
    }
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-3xl text-foreground">FAQs</h1>
          <p className="font-sans text-sm text-muted-foreground mt-1">{faqs.length} questions</p>
        </div>
        <Button onClick={handleNew} className="font-sans gap-2">
          <Plus className="w-4 h-4" /> Add FAQ
        </Button>
      </div>

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6 mb-6 space-y-4">
          <h2 className="font-sans text-sm font-semibold text-foreground">{editing ? 'Edit FAQ' : 'New FAQ'}</h2>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Question *</label>
            <Input value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })} className="font-sans" />
          </div>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Answer *</label>
            <textarea value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })} rows={4} className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-y" />
          </div>
          <div className="grid sm:grid-cols-3 gap-4 items-end">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Category</label>
              <Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Ordering" className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Display Order</label>
              <Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} className="font-sans" />
            </div>
            <label className="flex items-center gap-3 pb-1 cursor-pointer">
              <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} className="w-4 h-4 accent-primary" />
              <span className="font-sans text-sm text-foreground">Active</span>
            </label>
          </div>
          <div className="flex gap-3">
            <Button onClick={handleSave} disabled={saving} size="sm" className="font-sans">{saving ? 'Saving…' : 'Save'}</Button>
            <Button onClick={() => setShowForm(false)} variant="outline" size="sm" className="font-sans">Cancel</Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">Loading…</div>
      ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden divide-y divide-border">
          {faqs.map((faq) => (
            <div key={faq.id} className="px-5 py-4 flex items-start gap-4 hover:bg-muted/10 transition-colors">
              <div className="flex-1 min-w-0">
                <p className="font-sans text-sm font-medium text-foreground mb-1">{faq.question}</p>
                <p className="font-sans text-sm text-muted-foreground line-clamp-2">{faq.answer}</p>
                <div className="flex items-center gap-3 mt-1.5">
                  <span className="font-sans text-xs text-muted-foreground">{faq.category}</span>
                  {!faq.is_active && <span className="font-sans text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">Hidden</span>}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handleEdit(faq)}>
                  <Pencil className="w-3.5 h-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(faq.id)}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
