import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Plus, X } from 'lucide-react'
import { getProducts, createProduct, updateProduct } from '../../lib/api'
import type { Product } from '../../lib/types'
import { CATEGORIES, OCCASIONS } from '../../lib/types'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Separator } from '../ui/separator'
import { cn } from '../../lib/utils'

const STOCK_STATUSES = [
  { value: 'in_stock', label: 'In Stock' },
  { value: 'low_stock', label: 'Low Stock' },
  { value: 'out_of_stock', label: 'Out of Stock' },
  { value: 'made_to_order', label: 'Made to Order' },
]

const PRICE_TYPES = [
  { value: 'fixed', label: 'Fixed Price' },
  { value: 'from', label: 'From Price' },
  { value: 'custom', label: 'Custom Quote' },
  { value: 'quote', label: 'Quote Only' },
]

type FormState = Omit<Product, 'id' | 'created_at' | 'updated_at'>

const defaultForm: FormState = {
  slug: '',
  name: '',
  category: CATEGORIES[0],
  short_description: '',
  description: '',
  price: 0,
  price_type: 'fixed',
  compare_at_price: null,
  image_url: '',
  gallery_images: [],
  tags: [],
  occasions: [],
  options: [],
  stock_status: 'in_stock',
  quantity_available: null,
  is_featured: false,
  is_bestseller: false,
  is_customizable: false,
  is_bulk_friendly: false,
  display_order: 0,
  seo_title: '',
  seo_description: '',
}

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
}

export function AdminAddEditProduct() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const isNew = id === 'new'

  const [form, setForm] = useState<FormState>(defaultForm)
  const [loading, setLoading] = useState(!isNew)
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [newGalleryUrl, setNewGalleryUrl] = useState('')
  const [newTag, setNewTag] = useState('')
  const [newOptionName, setNewOptionName] = useState('')
  const [newOptionValues, setNewOptionValues] = useState('')

  useEffect(() => {
    if (!isNew && id) {
      getProducts()
        .then((products) => {
          const p = products.find((x) => x.id === id)
          if (!p) { navigate('/admin/products'); return }
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { id: _id, created_at: _c, updated_at: _u, ...rest } = p
          setForm(rest as FormState)
        })
        .catch(console.error)
        .finally(() => setLoading(false))
    }
  }, [id, isNew, navigate])

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }))

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!form.name.trim()) errs.name = 'Name is required'
    if (!form.slug.trim()) errs.slug = 'Slug is required'
    if (!form.image_url.trim()) errs.image_url = 'Main image URL is required'
    if (form.price_type !== 'custom' && form.price_type !== 'quote' && form.price <= 0) errs.price = 'Price must be greater than 0'
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }

    setSaving(true)
    try {
      if (isNew) {
        await createProduct(form)
      } else {
        await updateProduct(id!, form)
      }
      navigate('/admin/products')
    } catch (err) {
      alert('Failed to save product. Please try again.')
      console.error(err)
    }
    setSaving(false)
  }

  if (loading) {
    return <div className="p-8 font-sans text-sm text-muted-foreground">Loading…</div>
  }

  return (
    <div className="p-8 max-w-3xl">
      <button
        onClick={() => navigate('/admin/products')}
        className="flex items-center gap-2 font-sans text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Products
      </button>

      <h1 className="font-serif text-3xl text-foreground mb-8">{isNew ? 'New Product' : 'Edit Product'}</h1>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic info */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Basic Info</h2>
          <div className="space-y-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Product Name *</label>
              <Input
                value={form.name}
                onChange={(e) => {
                  set('name', e.target.value)
                  if (isNew) set('slug', slugify(e.target.value))
                }}
                placeholder="e.g. Rose Quartz Pillar Candle"
                className={cn('font-sans', errors.name && 'border-destructive')}
              />
              {errors.name && <p className="font-sans text-xs text-destructive mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Slug *</label>
              <Input
                value={form.slug}
                onChange={(e) => set('slug', slugify(e.target.value))}
                placeholder="rose-quartz-pillar-candle"
                className={cn('font-sans', errors.slug && 'border-destructive')}
              />
              {errors.slug && <p className="font-sans text-xs text-destructive mt-1">{errors.slug}</p>}
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Category</label>
                <select
                  value={form.category}
                  onChange={(e) => set('category', e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Display Order</label>
                <Input
                  type="number"
                  value={form.display_order}
                  onChange={(e) => set('display_order', parseInt(e.target.value) || 0)}
                  className="font-sans"
                />
              </div>
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Short Description</label>
              <Input
                value={form.short_description}
                onChange={(e) => set('short_description', e.target.value)}
                placeholder="One-line description for cards"
                className="font-sans"
              />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Full Description</label>
              <textarea
                value={form.description}
                onChange={(e) => set('description', e.target.value)}
                rows={4}
                placeholder="Detailed product description"
                className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-y"
              />
            </div>
          </div>
        </section>

        <Separator />

        {/* Pricing */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Pricing</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Price Type</label>
              <select
                value={form.price_type}
                onChange={(e) => set('price_type', e.target.value as Product['price_type'])}
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {PRICE_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Price (Rs.)</label>
              <Input
                type="number"
                value={form.price || ''}
                onChange={(e) => set('price', parseFloat(e.target.value) || 0)}
                placeholder="2500"
                className={cn('font-sans', errors.price && 'border-destructive')}
              />
              {errors.price && <p className="font-sans text-xs text-destructive mt-1">{errors.price}</p>}
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Compare at (Rs.)</label>
              <Input
                type="number"
                value={form.compare_at_price || ''}
                onChange={(e) => set('compare_at_price', parseFloat(e.target.value) || null)}
                placeholder="3500 (optional)"
                className="font-sans"
              />
            </div>
          </div>
        </section>

        <Separator />

        {/* Images */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Images</h2>
          <div className="space-y-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Main Image URL *</label>
              <Input
                value={form.image_url}
                onChange={(e) => set('image_url', e.target.value)}
                placeholder="https://..."
                className={cn('font-sans', errors.image_url && 'border-destructive')}
              />
              {form.image_url && (
                <img src={form.image_url} alt="preview" className="mt-2 w-24 h-24 rounded-lg object-cover border border-border" />
              )}
              {errors.image_url && <p className="font-sans text-xs text-destructive mt-1">{errors.image_url}</p>}
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Gallery Images</label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={newGalleryUrl}
                  onChange={(e) => setNewGalleryUrl(e.target.value)}
                  placeholder="Paste image URL and press +"
                  className="font-sans"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (newGalleryUrl.trim()) {
                      set('gallery_images', [...(form.gallery_images as string[]), newGalleryUrl.trim()])
                      setNewGalleryUrl('')
                    }
                  }}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {(form.gallery_images as string[]).map((url, i) => (
                  <div key={i} className="relative group">
                    <img src={url} alt="" className="w-16 h-16 rounded-lg object-cover border border-border" />
                    <button
                      type="button"
                      onClick={() => set('gallery_images', (form.gallery_images as string[]).filter((_, j) => j !== i))}
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <Separator />

        {/* Stock */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Stock</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Stock Status</label>
              <select
                value={form.stock_status}
                onChange={(e) => set('stock_status', e.target.value as Product['stock_status'])}
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {STOCK_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Qty Available (optional)</label>
              <Input
                type="number"
                value={form.quantity_available || ''}
                onChange={(e) => set('quantity_available', parseInt(e.target.value) || null)}
                className="font-sans"
              />
            </div>
          </div>
        </section>

        <Separator />

        {/* Options */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Product Options</h2>
          <div className="space-y-3 mb-4">
            {(form.options as { name: string; values: string[] }[]).map((opt, i) => (
              <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/20">
                <div className="flex-1">
                  <p className="font-sans text-sm font-medium text-foreground">{opt.name}</p>
                  <p className="font-sans text-xs text-muted-foreground">{opt.values.join(', ')}</p>
                </div>
                <button
                  type="button"
                  onClick={() => set('options', (form.options as { name: string; values: string[] }[]).filter((_, j) => j !== i))}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          <div className="p-4 rounded-lg border border-dashed border-border space-y-3">
            <Input
              value={newOptionName}
              onChange={(e) => setNewOptionName(e.target.value)}
              placeholder="Option name (e.g. Scent, Size)"
              className="font-sans"
            />
            <Input
              value={newOptionValues}
              onChange={(e) => setNewOptionValues(e.target.value)}
              placeholder="Values, comma-separated (e.g. Rose, Vanilla, Jasmine)"
              className="font-sans"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                if (newOptionName.trim() && newOptionValues.trim()) {
                  set('options', [
                    ...(form.options as { name: string; values: string[] }[]),
                    { name: newOptionName.trim(), values: newOptionValues.split(',').map((v) => v.trim()).filter(Boolean) },
                  ])
                  setNewOptionName('')
                  setNewOptionValues('')
                }
              }}
            >
              <Plus className="w-4 h-4 mr-1" /> Add Option
            </Button>
          </div>
        </section>

        <Separator />

        {/* Tags & Occasions */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Tags & Occasions</h2>
          <div className="space-y-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-2 block">Tags</label>
              <div className="flex gap-2 mb-2">
                <Input value={newTag} onChange={(e) => setNewTag(e.target.value)} onKeyDown={(e) => {
                  if (e.key === 'Enter') { e.preventDefault(); if (newTag.trim()) { set('tags', [...(form.tags as string[]), newTag.trim()]); setNewTag('') } }
                }} placeholder="Type tag and press Enter" className="font-sans" />
                <Button type="button" variant="outline" size="sm" onClick={() => { if (newTag.trim()) { set('tags', [...(form.tags as string[]), newTag.trim()]); setNewTag('') } }}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(form.tags as string[]).map((tag, i) => (
                  <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-accent border border-border font-sans text-xs text-foreground">
                    {tag}
                    <button type="button" onClick={() => set('tags', (form.tags as string[]).filter((_, j) => j !== i))}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-2 block">Occasions</label>
              <div className="flex flex-wrap gap-2">
                {OCCASIONS.map((occ) => (
                  <button
                    key={occ}
                    type="button"
                    onClick={() => {
                      const occs = form.occasions as string[]
                      set('occasions', occs.includes(occ) ? occs.filter((o) => o !== occ) : [...occs, occ])
                    }}
                    className={cn(
                      'px-3 py-1 rounded-full border text-xs font-sans transition-all',
                      (form.occasions as string[]).includes(occ)
                        ? 'border-primary bg-accent text-foreground'
                        : 'border-border text-muted-foreground hover:border-primary/40'
                    )}
                  >
                    {occ}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <Separator />

        {/* Flags */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Flags</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {([
              { key: 'is_featured', label: 'Featured on Homepage' },
              { key: 'is_bestseller', label: 'Bestseller' },
              { key: 'is_customizable', label: 'Customizable' },
              { key: 'is_bulk_friendly', label: 'Bulk Friendly' },
            ] as { key: keyof FormState; label: string }[]).map(({ key, label }) => (
              <label key={key} className="flex items-center gap-3 p-3 rounded-lg border border-border cursor-pointer hover:border-primary/40 transition-colors">
                <input
                  type="checkbox"
                  checked={form[key] as boolean}
                  onChange={(e) => set(key, e.target.checked)}
                  className="w-4 h-4 accent-primary"
                />
                <span className="font-sans text-sm text-foreground">{label}</span>
              </label>
            ))}
          </div>
        </section>

        <Separator />

        {/* SEO */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">SEO</h2>
          <div className="space-y-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">SEO Title</label>
              <Input value={form.seo_title} onChange={(e) => set('seo_title', e.target.value)} placeholder="Leave blank to use product name" className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Meta Description</label>
              <textarea value={form.seo_description} onChange={(e) => set('seo_description', e.target.value)} rows={2} placeholder="160 characters max" className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
            </div>
          </div>
        </section>

        <div className="flex gap-3 pt-4">
          <Button type="submit" size="lg" disabled={saving} className="font-sans">
            {saving ? 'Saving…' : isNew ? 'Create Product' : 'Save Changes'}
          </Button>
          <Button type="button" variant="outline" size="lg" onClick={() => navigate('/admin/products')} className="font-sans">
            Cancel
          </Button>
        </div>
      </form>
    </div>
  )
}
