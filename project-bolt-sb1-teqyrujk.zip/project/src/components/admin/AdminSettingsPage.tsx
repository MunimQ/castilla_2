import { useEffect, useState } from 'react'
import { getSiteSettings, upsertSiteSetting } from '../../lib/api'
import type { SiteSettings } from '../../lib/types'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Separator } from '../ui/separator'

export function AdminSettingsPage() {
  const [settings, setSettings] = useState<SiteSettings>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    getSiteSettings()
      .then(setSettings)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const set = <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) =>
    setSettings((prev) => ({ ...prev, [key]: value }))

  const handleSave = async () => {
    setSaving(true)
    try {
      await Promise.all(
        Object.entries(settings).map(([key, value]) => upsertSiteSetting(key, value))
      )
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } catch {
      alert('Failed to save settings.')
    }
    setSaving(false)
  }

  if (loading) return <div className="p-8 font-sans text-sm text-muted-foreground">Loading…</div>

  const announcement = settings.announcement_bar || { text: '', is_active: false }
  const hero = settings.hero || { headline: '', subheadline: '', trust_line: '' }
  const contact = settings.contact || { phone: '', whatsapp: '', instagram_url: '', email: '', address: '' }
  const delivery = settings.delivery || { note: '', cities: [] }
  const seo = settings.seo || { site_title: '', meta_description: '', og_image: '' }
  const footer = settings.footer || { tagline: '', copyright: '' }

  return (
    <div className="p-8 max-w-2xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl text-foreground">Site Settings</h1>
          <p className="font-sans text-sm text-muted-foreground mt-1">Manage your storefront content</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="font-sans">
          {saving ? 'Saving…' : saved ? 'Saved!' : 'Save All'}
        </Button>
      </div>

      <div className="space-y-8">
        {/* Announcement bar */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Announcement Bar</h2>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={announcement.is_active}
                onChange={(e) => set('announcement_bar', { ...announcement, is_active: e.target.checked })}
                className="w-4 h-4 accent-primary"
              />
              <span className="font-sans text-sm text-foreground">Show announcement bar</span>
            </label>
            <Input
              value={announcement.text}
              onChange={(e) => set('announcement_bar', { ...announcement, text: e.target.value })}
              placeholder="Free delivery on orders above Rs. 5,000 · WhatsApp us to customise!"
              className="font-sans"
            />
          </div>
        </section>

        <Separator />

        {/* Hero */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Hero Section</h2>
          <div className="space-y-3">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Headline</label>
              <Input value={hero.headline} onChange={(e) => set('hero', { ...hero, headline: e.target.value })} className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Subheadline</label>
              <Input value={hero.subheadline} onChange={(e) => set('hero', { ...hero, subheadline: e.target.value })} className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Trust Line</label>
              <Input value={hero.trust_line} onChange={(e) => set('hero', { ...hero, trust_line: e.target.value })} placeholder="Trusted by 500+ happy customers…" className="font-sans" />
            </div>
          </div>
        </section>

        <Separator />

        {/* Contact */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Contact Info</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {([
              { key: 'phone', label: 'Phone', placeholder: '+92 300 1234567' },
              { key: 'whatsapp', label: 'WhatsApp Number', placeholder: '923001234567 (no + or spaces)' },
              { key: 'instagram_url', label: 'Instagram URL', placeholder: 'https://instagram.com/castilla' },
              { key: 'email', label: 'Email', placeholder: 'hello@castilla.pk' },
            ] as { key: keyof typeof contact; label: string; placeholder: string }[]).map(({ key, label, placeholder }) => (
              <div key={key}>
                <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">{label}</label>
                <Input
                  value={(contact[key] as string) || ''}
                  onChange={(e) => set('contact', { ...contact, [key]: e.target.value })}
                  placeholder={placeholder}
                  className="font-sans"
                />
              </div>
            ))}
            <div className="sm:col-span-2">
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Address</label>
              <Input value={contact.address} onChange={(e) => set('contact', { ...contact, address: e.target.value })} placeholder="Studio address" className="font-sans" />
            </div>
          </div>
        </section>

        <Separator />

        {/* Delivery */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Delivery</h2>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Delivery Note</label>
            <textarea
              value={delivery.note}
              onChange={(e) => set('delivery', { ...delivery, note: e.target.value })}
              rows={2}
              className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>
        </section>

        <Separator />

        {/* SEO */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">SEO</h2>
          <div className="space-y-3">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Site Title</label>
              <Input value={seo.site_title} onChange={(e) => set('seo', { ...seo, site_title: e.target.value })} className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Meta Description</label>
              <textarea value={seo.meta_description} onChange={(e) => set('seo', { ...seo, meta_description: e.target.value })} rows={2} className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
            </div>
          </div>
        </section>

        <Separator />

        {/* Footer */}
        <section>
          <h2 className="font-sans text-sm font-semibold text-foreground uppercase tracking-widest mb-4">Footer</h2>
          <div className="space-y-3">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Tagline</label>
              <Input value={footer.tagline} onChange={(e) => set('footer', { ...footer, tagline: e.target.value })} className="font-sans" />
            </div>
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Copyright Text</label>
              <Input value={footer.copyright} onChange={(e) => set('footer', { ...footer, copyright: e.target.value })} className="font-sans" />
            </div>
          </div>
        </section>
      </div>

      <div className="mt-8 pt-6 border-t border-border">
        <Button onClick={handleSave} size="lg" disabled={saving} className="font-sans">
          {saving ? 'Saving…' : saved ? 'Saved!' : 'Save All Settings'}
        </Button>
      </div>
    </div>
  )
}
