import { useEffect, useState } from 'react'
import { getCustomGiftRequests, updateCustomGiftRequestStatus } from '../../lib/api'
import type { CustomGiftRequest } from '../../lib/types'
import { Badge } from '../ui/badge'
import { cn } from '../../lib/utils'

const REQUEST_STATUSES = ['New', 'Contacted', 'Quoted', 'Confirmed', 'Completed', 'Declined']

const statusColor = (status: string) => {
  switch (status) {
    case 'New': return 'bg-blue-50 text-blue-700 border-blue-200'
    case 'Contacted': return 'bg-purple-50 text-purple-700 border-purple-200'
    case 'Quoted': return 'bg-indigo-50 text-indigo-700 border-indigo-200'
    case 'Confirmed': return 'bg-amber-50 text-amber-700 border-amber-200'
    case 'Completed': return 'bg-green-50 text-green-700 border-green-200'
    case 'Declined': return 'bg-red-50 text-red-700 border-red-200'
    default: return ''
  }
}

export function AdminCustomRequestsPage() {
  const [requests, setRequests] = useState<CustomGiftRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [updating, setUpdating] = useState<string | null>(null)

  useEffect(() => {
    getCustomGiftRequests()
      .then(setRequests)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const handleStatusChange = async (id: string, status: string) => {
    setUpdating(id)
    try {
      await updateCustomGiftRequestStatus(id, status)
      setRequests((prev) => prev.map((r) => r.id === id ? { ...r, status } : r))
    } catch {
      alert('Failed to update status.')
    }
    setUpdating(null)
  }

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="font-serif text-3xl text-foreground">Custom Gift Requests</h1>
        <p className="font-sans text-sm text-muted-foreground mt-1">{requests.length} total</p>
      </div>

      {loading ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">Loading…</div>
      ) : requests.length === 0 ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">No requests yet.</div>
      ) : (
        <div className="space-y-3">
          {requests.map((req) => (
            <div key={req.id} className="bg-card rounded-xl border border-border overflow-hidden">
              <button
                className="w-full text-left px-5 py-4 hover:bg-muted/20 transition-colors"
                onClick={() => setExpanded(expanded === req.id ? null : req.id)}
              >
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-sans text-sm font-semibold text-foreground">{req.name}</span>
                  <Badge variant="secondary" className={cn('font-sans text-xs', statusColor(req.status))}>
                    {req.status}
                  </Badge>
                  <span className="font-sans text-sm text-muted-foreground flex-1">{req.occasion}</span>
                  <span className="font-sans text-sm text-muted-foreground">{req.budget_range}</span>
                  <span className="font-sans text-xs text-muted-foreground">
                    {new Date(req.created_at).toLocaleDateString('en-PK')}
                  </span>
                </div>
              </button>

              {expanded === req.id && (
                <div className="border-t border-border px-5 py-5 bg-muted/10 space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-1">Contact</p>
                      <p className="font-sans text-sm text-foreground">{req.phone}</p>
                      {req.email && <p className="font-sans text-sm text-muted-foreground">{req.email}</p>}
                    </div>
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-1">Budget</p>
                      <p className="font-sans text-sm text-foreground">{req.budget_range}</p>
                    </div>
                    {req.delivery_city && (
                      <div>
                        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-1">Recipient / City</p>
                        <p className="font-sans text-sm text-foreground">{req.delivery_city}</p>
                      </div>
                    )}
                    {(req.preferred_products as string[])?.length > 0 && (
                      <div>
                        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-1">Product Ideas</p>
                        <p className="font-sans text-sm text-foreground">{(req.preferred_products as string[]).join(', ')}</p>
                      </div>
                    )}
                  </div>
                  {req.message && (
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-1">Message</p>
                      <p className="font-sans text-sm text-foreground leading-relaxed">{req.message}</p>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <select
                      value={req.status}
                      onChange={(e) => handleStatusChange(req.id, e.target.value)}
                      disabled={updating === req.id}
                      className="h-9 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      {REQUEST_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    {updating === req.id && <span className="font-sans text-xs text-muted-foreground">Updating…</span>}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
