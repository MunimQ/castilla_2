import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Package, ShoppingCart, Sparkles, Users2, TrendingUp } from 'lucide-react'
import { getProducts, getOrders, getCustomGiftRequests, getBulkRequests } from '../../lib/api'
import { formatPrice } from '../../lib/types'

export function AdminDashboard() {
  const [stats, setStats] = useState({
    products: 0,
    orders: 0,
    customRequests: 0,
    bulkRequests: 0,
    revenue: 0,
    newOrders: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([getProducts(), getOrders(), getCustomGiftRequests(), getBulkRequests()])
      .then(([products, orders, customReqs, bulkReqs]) => {
        setStats({
          products: products.length,
          orders: orders.length,
          customRequests: customReqs.length,
          bulkRequests: bulkReqs.length,
          revenue: orders.reduce((sum, o) => sum + (o.total || 0), 0),
          newOrders: orders.filter((o) => o.status === 'New').length,
        })
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const cards = [
    { label: 'Products', value: stats.products, icon: Package, to: '/admin/products', color: 'text-blue-600 bg-blue-50' },
    { label: 'Total Orders', value: stats.orders, icon: ShoppingCart, to: '/admin/orders', color: 'text-green-600 bg-green-50', sub: `${stats.newOrders} new` },
    { label: 'Custom Requests', value: stats.customRequests, icon: Sparkles, to: '/admin/custom-requests', color: 'text-purple-600 bg-purple-50' },
    { label: 'Bulk Requests', value: stats.bulkRequests, icon: Users2, to: '/admin/bulk-requests', color: 'text-orange-600 bg-orange-50' },
  ]

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="font-serif text-3xl text-foreground">Dashboard</h1>
        <p className="font-sans text-sm text-muted-foreground mt-1">Overview of your store</p>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        {cards.map(({ label, value, icon: Icon, to, color, sub }) => (
          <Link
            key={label}
            to={to}
            className="bg-card rounded-xl border border-border p-5 hover:border-primary/30 transition-colors group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <TrendingUp className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <p className="font-sans text-2xl font-bold text-foreground mb-0.5">
              {loading ? '—' : value}
            </p>
            <p className="font-sans text-sm text-muted-foreground">{label}</p>
            {sub && !loading && <p className="font-sans text-xs text-primary mt-1">{sub}</p>}
          </Link>
        ))}
      </div>

      {/* Revenue */}
      <div className="bg-card rounded-xl border border-border p-6 mb-8">
        <p className="font-sans text-sm text-muted-foreground mb-1">Total Revenue</p>
        <p className="font-serif text-4xl text-foreground">{loading ? '—' : formatPrice(stats.revenue)}</p>
        <p className="font-sans text-xs text-muted-foreground mt-1">Sum of all placed orders</p>
      </div>

      {/* Quick links */}
      <div className="bg-card rounded-xl border border-border p-6">
        <h2 className="font-sans text-sm font-semibold text-foreground mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-3">
          <Link to="/admin/products/new" className="font-sans text-sm text-primary hover:underline">+ Add Product</Link>
          <span className="text-muted-foreground">·</span>
          <Link to="/admin/orders" className="font-sans text-sm text-primary hover:underline">View Orders</Link>
          <span className="text-muted-foreground">·</span>
          <Link to="/admin/settings" className="font-sans text-sm text-primary hover:underline">Site Settings</Link>
          <span className="text-muted-foreground">·</span>
          <Link to="/" target="_blank" className="font-sans text-sm text-primary hover:underline">View Storefront ↗</Link>
        </div>
      </div>
    </div>
  )
}
