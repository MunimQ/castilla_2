import { useEffect, useState } from 'react'
import { Plus, Pencil, Trash2, GripVertical } from 'lucide-react'
import { getAllInstagramItems, upsertInstagramItem, deleteInstagramItem } from '../../lib/api'
import type { InstagramItem } from '../../lib/types'
import { Button } from '../ui/button'
import { Input } from '../ui/input'

type FormState = { image_url: string; caption: string; link: string; display_order: number; is_active: boolean }

const emptyForm: FormState = { image_url: '', caption: '', link: '', display_order: 0, is_active: true }

export function AdminInstagramPage() {
  const [items, setItems] = useState<InstagramItem[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [showForm, setShowForm] = useState(false)

  const load = () => {
    setLoading(true)
    getAllInstagramItems().then(setItems).catch(console.error).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleEdit = (item: InstagramItem) => {
    setEditing(item.id)
    setForm({ image_url: item.image_url, caption: item.caption, link: item.link, display_order: item.display_order, is_active: item.is_active })
    setShowForm(true)
  }

  const handleNew = () => {
    setEditing(null)
    setForm({ ...emptyForm, display_order: items.length + 1 })
    setShowForm(true)
  }

  const handleSave = async () => {
    if (!form.image_url.trim()) return
    setSaving(true)
    try {
      await upsertInstagramItem(editing ? { id: editing, ...form } : form)
      load()
      setShowForm(false)
      setEditing(null)
    } catch {
      alert('Failed to save.')
    }
    setSaving(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this item?')) return
    try {
      await deleteInstagramItem(id)
      setItems((prev) => prev.filter((i) => i.id !== id))
    } catch {
      alert('Failed to delete.')
    }
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-3xl text-foreground">Instagram Carousel</h1>
          <p className="font-sans text-sm text-muted-foreground mt-1">{items.length} items</p>
        </div>
        <Button onClick={handleNew} className="font-sans gap-2">
          <Plus className="w-4 h-4" /> Add Item
        </Button>
      </div>

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6 mb-6 space-y-4">
          <h2 className="font-sans text-sm font-semibold text-foreground">{editing ? 'Edit Item' : 'New Item'}</h2>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Image URL *</label>
            <Input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://..." className="font-sans" />
            {form.image_url && <img src={form.image_url} alt="" className="mt-2 w-24 h-24 rounded-lg object-cover border border-border" />}
          </div>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Caption</label>
            <Input value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} placeholder="Caption text" className="font-sans" />
          </div>
          <div>
            <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Post Link (optional)</label>
            <Input value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })} placeholder="https://instagram.com/p/..." className="font-sans" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="font-sans text-sm font-medium text-foreground mb-1.5 block">Display Order</label>
              <Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} className="font-sans" />
            </div>
            <label className="flex items-center gap-3 mt-6 cursor-pointer">
              <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} className="w-4 h-4 accent-primary" />
              <span className="font-sans text-sm text-foreground">Active</span>
            </label>
          </div>
          <div className="flex gap-3">
            <Button onClick={handleSave} disabled={saving} size="sm" className="font-sans">{saving ? 'Saving…' : 'Save'}</Button>
            <Button onClick={() => setShowForm(false)} variant="outline" size="sm" className="font-sans">Cancel</Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">Loading…</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((item) => (
            <div key={item.id} className="bg-card rounded-xl border border-border overflow-hidden group">
              <div className="aspect-square relative">
                <img src={item.image_url} alt={item.caption} className="w-full h-full object-cover" />
                {!item.is_active && (
                  <div className="absolute inset-0 bg-background/60 flex items-center justify-center">
                    <span className="font-sans text-xs text-muted-foreground bg-background px-2 py-1 rounded">Hidden</span>
                  </div>
                )}
              </div>
              <div className="p-3">
                <p className="font-sans text-sm text-foreground line-clamp-2 mb-3">{item.caption || '(no caption)'}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <GripVertical className="w-4 h-4" />
                    <span className="font-sans text-xs">#{item.display_order}</span>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => handleEdit(item)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
