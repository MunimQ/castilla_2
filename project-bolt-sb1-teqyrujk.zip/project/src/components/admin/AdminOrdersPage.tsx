import { useEffect, useState } from 'react'
import { getOrders, updateOrderStatus } from '../../lib/api'
import type { Order } from '../../lib/types'
import { formatPrice, ORDER_STATUSES } from '../../lib/types'
import { Badge } from '../ui/badge'
import { cn } from '../../lib/utils'

const statusColor = (status: string) => {
  switch (status) {
    case 'New': return 'bg-blue-50 text-blue-700 border-blue-200'
    case 'Contacted': return 'bg-purple-50 text-purple-700 border-purple-200'
    case 'Confirmed': return 'bg-indigo-50 text-indigo-700 border-indigo-200'
    case 'Preparing': return 'bg-amber-50 text-amber-700 border-amber-200'
    case 'Ready for Dispatch': return 'bg-orange-50 text-orange-700 border-orange-200'
    case 'Completed': return 'bg-green-50 text-green-700 border-green-200'
    case 'Cancelled': return 'bg-red-50 text-red-700 border-red-200'
    default: return ''
  }
}

export function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [updating, setUpdating] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState('')

  useEffect(() => {
    getOrders()
      .then(setOrders)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const handleStatusChange = async (id: string, status: string) => {
    setUpdating(id)
    try {
      await updateOrderStatus(id, status)
      setOrders((prev) => prev.map((o) => o.id === id ? { ...o, status } : o))
    } catch {
      alert('Failed to update status.')
    }
    setUpdating(null)
  }

  const filtered = statusFilter ? orders.filter((o) => o.status === statusFilter) : orders

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-3xl text-foreground">Orders</h1>
          <p className="font-sans text-sm text-muted-foreground mt-1">{orders.length} total</p>
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="">All Statuses</option>
          {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">Loading…</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center font-sans text-sm text-muted-foreground">No orders found.</div>
      ) : (
        <div className="space-y-3">
          {filtered.map((order) => (
            <div key={order.id} className="bg-card rounded-xl border border-border overflow-hidden">
              {/* Row */}
              <button
                className="w-full text-left px-5 py-4 hover:bg-muted/20 transition-colors"
                onClick={() => setExpanded(expanded === order.id ? null : order.id)}
              >
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-sans text-sm font-semibold text-foreground">{order.order_number}</span>
                  <Badge variant="secondary" className={cn('font-sans text-xs', statusColor(order.status))}>
                    {order.status}
                  </Badge>
                  <span className="font-sans text-sm text-muted-foreground flex-1">{order.customer_name} · {order.phone}</span>
                  <span className="font-sans text-sm font-medium text-foreground">{formatPrice(order.total)}</span>
                  <span className="font-sans text-xs text-muted-foreground">
                    {new Date(order.created_at).toLocaleDateString('en-PK')}
                  </span>
                </div>
              </button>

              {/* Expanded detail */}
              {expanded === order.id && (
                <div className="border-t border-border px-5 py-5 bg-muted/10 space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Customer</p>
                      <p className="font-sans text-sm text-foreground font-medium">{order.customer_name}</p>
                      <p className="font-sans text-sm text-muted-foreground">{order.phone}</p>
                      {order.email && <p className="font-sans text-sm text-muted-foreground">{order.email}</p>}
                    </div>
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Delivery</p>
                      <p className="font-sans text-sm text-foreground">{order.delivery_city}</p>
                      <p className="font-sans text-sm text-muted-foreground">{order.delivery_address}</p>
                    </div>
                    <div>
                      <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Payment</p>
                      <p className="font-sans text-sm text-foreground">{order.payment_method}</p>
                    </div>
                    {order.notes && (
                      <div>
                        <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Notes</p>
                        <p className="font-sans text-sm text-foreground">{order.notes}</p>
                      </div>
                    )}
                  </div>

                  {/* Items */}
                  <div>
                    <p className="font-sans text-xs text-muted-foreground uppercase tracking-widest mb-2">Items</p>
                    <div className="space-y-1.5">
                      {(order.items as Order['items']).map((item, i) => (
                        <div key={i} className="flex items-center justify-between font-sans text-sm">
                          <span className="text-foreground">
                            {item.name}
                            {Object.keys(item.selected_options).length > 0 && (
                              <span className="text-muted-foreground text-xs ml-1">
                                ({Object.entries(item.selected_options).map(([k, v]) => `${k}: ${v}`).join(', ')})
                              </span>
                            )}
                            {' '}× {item.quantity}
                          </span>
                          <span className="text-muted-foreground">{formatPrice(item.line_total)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between font-sans text-sm font-semibold pt-2 border-t border-border">
                        <span>Total</span>
                        <span>{formatPrice(order.total)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status update */}
                  <div className="flex items-center gap-3">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      disabled={updating === order.id}
                      className="h-9 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    {updating === order.id && <span className="font-sans text-xs text-muted-foreground">Updating…</span>}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
