import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Pencil, Trash2, Search } from 'lucide-react'
import { getProducts, deleteProduct } from '../../lib/api'
import type { Product } from '../../lib/types'
import { formatPrice, CATEGORIES } from '../../lib/types'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Badge } from '../ui/badge'

export function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('')
  const [deleting, setDeleting] = useState<string | null>(null)

  const load = () => {
    setLoading(true)
    getProducts()
      .then(setProducts)
      .catch(console.error)
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return
    setDeleting(id)
    try {
      await deleteProduct(id)
      setProducts((prev) => prev.filter((p) => p.id !== id))
    } catch (err) {
      alert('Failed to delete product.')
    }
    setDeleting(null)
  }

  const filtered = products.filter((p) => {
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase())
    const matchCat = !catFilter || p.category === catFilter
    return matchSearch && matchCat
  })

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-3xl text-foreground">Products</h1>
          <p className="font-sans text-sm text-muted-foreground mt-1">{products.length} total</p>
        </div>
        <Button asChild className="font-sans gap-2">
          <Link to="/admin/products/new">
            <Plus className="w-4 h-4" />
            Add Product
          </Link>
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-6">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products…"
            className="pl-9 font-sans text-sm"
          />
        </div>
        <select
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="h-10 px-3 rounded-md border border-input bg-background text-sm font-sans focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="">All Categories</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {loading ? (
          <div className="p-12 text-center font-sans text-sm text-muted-foreground">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center font-sans text-sm text-muted-foreground">No products found.</div>
        ) : (
          <table className="w-full">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left font-sans text-xs text-muted-foreground font-medium px-4 py-3">Product</th>
                <th className="text-left font-sans text-xs text-muted-foreground font-medium px-4 py-3 hidden md:table-cell">Category</th>
                <th className="text-left font-sans text-xs text-muted-foreground font-medium px-4 py-3 hidden sm:table-cell">Price</th>
                <th className="text-left font-sans text-xs text-muted-foreground font-medium px-4 py-3 hidden lg:table-cell">Status</th>
                <th className="px-4 py-3 w-24"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-accent flex-shrink-0">
                        <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-sans text-sm font-medium text-foreground line-clamp-1">{p.name}</p>
                        <p className="font-sans text-xs text-muted-foreground">{p.slug}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className="font-sans text-sm text-muted-foreground">{p.category}</span>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="font-sans text-sm text-foreground">
                      {p.price_type === 'custom' || p.price_type === 'quote' ? 'Custom' : formatPrice(p.price)}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <Badge
                      variant="secondary"
                      className={
                        p.stock_status === 'in_stock' ? 'bg-green-50 text-green-700 border-green-200' :
                        p.stock_status === 'low_stock' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                        p.stock_status === 'out_of_stock' ? 'bg-red-50 text-red-700 border-red-200' :
                        'font-sans text-xs'
                      }
                    >
                      {p.stock_status.replace('_', ' ')}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 justify-end">
                      <Button asChild variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Link to={`/admin/products/${p.id}`}><Pencil className="w-3.5 h-3.5" /></Link>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => handleDelete(p.id, p.name)}
                        disabled={deleting === p.id}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
