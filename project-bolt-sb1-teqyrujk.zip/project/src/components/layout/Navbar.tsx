import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ShoppingBag, Search, Menu, X, Phone, Camera } from 'lucide-react'
import { useCart } from '../../contexts/CartContext'
import { Button } from '../ui/button'
import { Input } from '../ui/input'

export function Navbar() {
  const { itemCount, openCart } = useCart()
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const navigate = useNavigate()

  const whatsapp = import.meta.env.VITE_WHATSAPP_NUMBER
  const instagram = import.meta.env.VITE_INSTAGRAM_URL
  const phone = import.meta.env.VITE_CONTACT_PHONE

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/shop?q=${encodeURIComponent(searchQuery.trim())}`)
      setSearchOpen(false)
      setSearchQuery('')
    }
  }

  const navLinks = [
    { label: 'Home', to: '/' },
    { label: 'Shop', to: '/shop' },
    { label: 'Collections', to: '/collections' },
    { label: 'Custom Gift Packs', to: '/custom-gift-packs' },
    { label: 'Bulk Gifting', to: '/bulk-gifting' },
    { label: 'About', to: '/about' },
    { label: 'Contact', to: '/contact' },
  ]

  return (
    <>
      {/* Desktop nav */}
      <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex-shrink-0">
              <span className="font-serif text-2xl tracking-widest text-foreground">
                Castilla
              </span>
            </Link>

            {/* Desktop links */}
            <nav className="hidden lg:flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="font-sans text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Search */}
              {searchOpen ? (
                <form onSubmit={handleSearch} className="hidden sm:flex items-center gap-1">
                  <Input
                    autoFocus
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search products…"
                    className="h-8 w-40 text-sm"
                  />
                  <button type="submit" className="p-1.5 rounded hover:bg-accent transition-colors">
                    <Search className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSearchOpen(false)}
                    className="p-1.5 rounded hover:bg-accent transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  className="hidden sm:flex p-2 rounded-full hover:bg-accent transition-colors"
                  aria-label="Search"
                >
                  <Search className="w-4 h-4 text-muted-foreground" />
                </button>
              )}

              {/* Instagram */}
              {instagram && (
                <a
                  href={instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hidden sm:flex p-2 rounded-full hover:bg-accent transition-colors"
                  aria-label="Instagram"
                >
                  <Camera className="w-4 h-4 text-muted-foreground" />
                </a>
              )}

              {/* Phone */}
              {phone && (
                <a
                  href={`tel:${phone}`}
                  className="hidden sm:flex p-2 rounded-full hover:bg-accent transition-colors"
                  aria-label="Call us"
                >
                  <Phone className="w-4 h-4 text-muted-foreground" />
                </a>
              )}

              {/* Cart */}
              <button
                onClick={openCart}
                className="relative p-2 rounded-full hover:bg-accent transition-colors"
                aria-label="Cart"
              >
                <ShoppingBag className="w-5 h-5 text-foreground" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-4 h-4 flex items-center justify-center font-sans">
                    {itemCount > 9 ? '9+' : itemCount}
                  </span>
                )}
              </button>

              {/* Mobile menu toggle */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="lg:hidden p-2 rounded-full hover:bg-accent transition-colors"
                aria-label="Menu"
              >
                {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile search */}
          {searchOpen && (
            <form onSubmit={handleSearch} className="sm:hidden pb-3 flex gap-2">
              <Input
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products…"
                className="h-9 text-sm flex-1"
              />
              <Button type="submit" size="sm">Search</Button>
            </form>
          )}
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <nav className="max-w-7xl mx-auto px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMenuOpen(false)}
                  className="block py-2.5 px-3 rounded-md font-sans text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                >
                  {link.label}
                </Link>
              ))}
              <div className="pt-3 flex gap-3 px-3">
                {whatsapp && (
                  <a
                    href={`https://wa.me/${whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 text-center py-2 rounded-md bg-green-50 text-green-700 text-sm font-sans font-medium"
                  >
                    WhatsApp Us
                  </a>
                )}
                <button
                  onClick={() => { setMenuOpen(false); setSearchOpen(true) }}
                  className="flex-1 text-center py-2 rounded-md bg-accent text-foreground text-sm font-sans font-medium"
                >
                  Search
                </button>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>
  )
}
