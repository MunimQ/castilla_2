import { Link } from 'react-router-dom'
import { Camera, Phone, Mail, MessageCircle, MapPin } from 'lucide-react'

export function Footer() {
  const whatsapp = import.meta.env.VITE_WHATSAPP_NUMBER
  const instagram = import.meta.env.VITE_INSTAGRAM_URL
  const phone = import.meta.env.VITE_CONTACT_PHONE
  const email = import.meta.env.VITE_EMAIL_ADDRESS

  return (
    <footer className="bg-card border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="block mb-3">
              <span className="font-serif text-2xl tracking-widest text-foreground">Castilla</span>
            </Link>
            <p className="font-sans text-sm text-muted-foreground leading-relaxed mb-4">
              Handcrafted with care, curated with love. Premium gifting and home décor made for moments worth remembering.
            </p>
            {/* Social links */}
            <div className="flex gap-3">
              {instagram && (
                <a
                  href={instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                  aria-label="Instagram"
                >
                  <Camera className="w-4 h-4" />
                </a>
              )}
              {whatsapp && (
                <a
                  href={`https://wa.me/${whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-muted-foreground hover:text-green-600 hover:bg-green-50 transition-colors"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              )}
              {phone && (
                <a
                  href={`tel:${phone}`}
                  className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                  aria-label="Phone"
                >
                  <Phone className="w-4 h-4" />
                </a>
              )}
              {email && (
                <a
                  href={`mailto:${email}`}
                  className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                  aria-label="Email"
                >
                  <Mail className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>

          {/* Shop */}
          <div>
            <h3 className="font-sans font-semibold text-foreground text-sm mb-4">Shop</h3>
            <ul className="space-y-2.5">
              {[
                { label: 'All Products', to: '/shop' },
                { label: 'Scented Candles', to: '/shop?category=Scented+Candles' },
                { label: 'Candle Bouquets', to: '/shop?category=Candle+Bouquets' },
                { label: 'Concrete Trays', to: '/shop?category=Concrete+Trays' },
                { label: 'Bubble Candles', to: '/shop?category=Bubble+Candles' },
                { label: 'Gift Packs', to: '/shop?category=Pre-Made+Gift+Packs' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="font-sans text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-sans font-semibold text-foreground text-sm mb-4">Services</h3>
            <ul className="space-y-2.5">
              {[
                { label: 'Custom Gift Packs', to: '/custom-gift-packs' },
                { label: 'Bulk & Event Gifting', to: '/bulk-gifting' },
                { label: 'Customised Cakes', to: '/shop?category=Customized+Cakes' },
                { label: 'Collections', to: '/collections' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="font-sans text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Info */}
          <div>
            <h3 className="font-sans font-semibold text-foreground text-sm mb-4">Information</h3>
            <ul className="space-y-2.5">
              {[
                { label: 'About Castilla', to: '/about' },
                { label: 'Delivery & Ordering', to: '/delivery' },
                { label: 'FAQs', to: '/faqs' },
                { label: 'Contact Us', to: '/contact' },
                { label: 'Privacy Policy', to: '/privacy' },
                { label: 'Terms & Conditions', to: '/terms' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="font-sans text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Location */}
            <div className="mt-4 flex items-start gap-2 text-xs text-muted-foreground font-sans">
              <MapPin className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
              <span>Karachi, Pakistan · Nationwide delivery</span>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-sans text-xs text-muted-foreground">
            © {new Date().getFullYear()} Castilla. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link to="/privacy" className="font-sans text-xs text-muted-foreground hover:text-foreground transition-colors">Privacy</Link>
            <Link to="/terms" className="font-sans text-xs text-muted-foreground hover:text-foreground transition-colors">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
