import { X } from 'lucide-react'
import { useState } from 'react'

interface AnnouncementBarProps {
  text?: string
}

export function AnnouncementBar({ text }: AnnouncementBarProps) {
  const [dismissed, setDismissed] = useState(false)

  const displayText = text || 'Free delivery on orders over Rs. 8,000 · Custom gift packs available · WhatsApp us for bulk orders'

  if (dismissed) return null

  return (
    <div className="bg-primary text-primary-foreground relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-center">
        <p className="font-sans text-xs text-center pr-8">{displayText}</p>
        <button
          onClick={() => setDismissed(true)}
          className="absolute right-4 p-1 rounded hover:bg-white/20 transition-colors"
          aria-label="Dismiss"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}
