import { X, ShoppingBag, Minus, Plus, Trash2, ArrowRight } from 'lucide-react'
import { useCart } from '../../contexts/CartContext'
import { formatPrice } from '../../lib/types'
import { Button } from '../ui/button'
import { Separator } from '../ui/separator'
import { useNavigate } from 'react-router-dom'

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQty, subtotal, itemCount } = useCart()
  const navigate = useNavigate()

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40"
        onClick={closeCart}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 h-full w-full max-w-sm bg-background shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-primary" />
            <span className="font-serif text-lg text-foreground">Your Cart</span>
            {itemCount > 0 && (
              <span className="bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-sans">
                {itemCount}
              </span>
            )}
          </div>
          <button
            onClick={closeCart}
            className="p-1.5 rounded-full hover:bg-accent transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4 py-12">
              <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center">
                <ShoppingBag className="w-7 h-7 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground font-sans">Your cart is empty</p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => { closeCart(); navigate('/shop') }}
                className="mt-2"
              >
                Browse Products
              </Button>
            </div>
          ) : (
            items.map((item) => (
              <div key={`${item.product_id}-${JSON.stringify(item.selected_options)}`} className="flex gap-3">
                {/* Image */}
                <div
                  className="w-18 h-18 rounded-lg overflow-hidden bg-accent flex-shrink-0 cursor-pointer"
                  style={{ width: 72, height: 72 }}
                  onClick={() => { closeCart(); navigate(`/products/${item.slug}`) }}
                >
                  <img
                    src={item.image_url || 'https://images.unsplash.com/photo-1602178781702-ec8e02b5e0e3?w=200'}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <p className="font-sans text-sm font-medium text-foreground line-clamp-2 leading-snug">{item.name}</p>
                  {Object.entries(item.selected_options).length > 0 && (
                    <p className="text-xs text-muted-foreground font-sans mt-0.5">
                      {Object.entries(item.selected_options).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                    </p>
                  )}
                  <p className="text-sm font-medium text-primary font-sans mt-1">
                    {item.price_type === 'custom' ? 'Custom Quote' : formatPrice(item.line_total)}
                  </p>

                  {/* Qty controls */}
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => updateQty(item.product_id, item.quantity - 1)}
                      className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-sans text-sm w-5 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQty(item.product_id, item.quantity + 1)}
                      className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => removeItem(item.product_id)}
                      className="ml-auto p-1 text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-border p-5 space-y-4 bg-card">
            <div className="flex justify-between items-center">
              <span className="font-sans text-sm text-muted-foreground">Subtotal</span>
              <span className="font-sans font-semibold text-foreground">{formatPrice(subtotal)}</span>
            </div>
            <p className="text-xs text-muted-foreground font-sans">
              Delivery charges calculated at checkout
            </p>
            <Separator />
            <div className="space-y-2">
              <Button
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => { closeCart(); navigate('/checkout') }}
              >
                Proceed to Checkout <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => { closeCart(); navigate('/shop') }}
              >
                Continue Shopping
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
