import React, { createContext, useContext, useEffect, useReducer } from 'react'
import type { CartItem, Product } from '../lib/types'

interface CartState {
  items: CartItem[]
  isOpen: boolean
}

type CartAction =
  | { type: 'ADD_ITEM'; payload: CartItem }
  | { type: 'REMOVE_ITEM'; payload: string } // product_id
  | { type: 'UPDATE_QTY'; payload: { product_id: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'TOGGLE_CART'; payload?: boolean }
  | { type: 'LOAD_CART'; payload: CartItem[] }

interface CartContextValue extends CartState {
  addItem: (product: Product, options?: Record<string, string>, qty?: number) => void
  removeItem: (productId: string) => void
  updateQty: (productId: string, quantity: number) => void
  clearCart: () => void
  openCart: () => void
  closeCart: () => void
  itemCount: number
  subtotal: number
}

const CartContext = createContext<CartContextValue | null>(null)

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'LOAD_CART':
      return { ...state, items: action.payload }

    case 'ADD_ITEM': {
      const existing = state.items.find(
        (i) =>
          i.product_id === action.payload.product_id &&
          JSON.stringify(i.selected_options) === JSON.stringify(action.payload.selected_options)
      )
      if (existing) {
        return {
          ...state,
          items: state.items.map((i) =>
            i.product_id === existing.product_id &&
            JSON.stringify(i.selected_options) === JSON.stringify(existing.selected_options)
              ? { ...i, quantity: i.quantity + action.payload.quantity, line_total: i.price * (i.quantity + action.payload.quantity) }
              : i
          ),
          isOpen: true,
        }
      }
      return { ...state, items: [...state.items, action.payload], isOpen: true }
    }

    case 'REMOVE_ITEM':
      return { ...state, items: state.items.filter((i) => i.product_id !== action.payload) }

    case 'UPDATE_QTY': {
      if (action.payload.quantity <= 0) {
        return { ...state, items: state.items.filter((i) => i.product_id !== action.payload.product_id) }
      }
      return {
        ...state,
        items: state.items.map((i) =>
          i.product_id === action.payload.product_id
            ? { ...i, quantity: action.payload.quantity, line_total: i.price * action.payload.quantity }
            : i
        ),
      }
    }

    case 'CLEAR_CART':
      return { ...state, items: [] }

    case 'TOGGLE_CART':
      return { ...state, isOpen: action.payload !== undefined ? action.payload : !state.isOpen }

    default:
      return state
  }
}

const CART_KEY = 'castilla_cart'

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, { items: [], isOpen: false })

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CART_KEY)
      if (saved) dispatch({ type: 'LOAD_CART', payload: JSON.parse(saved) })
    } catch {
      // ignore
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(state.items))
  }, [state.items])

  const addItem = (product: Product, options: Record<string, string> = {}, qty = 1) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        product_id: product.id,
        slug: product.slug,
        name: product.name,
        image_url: product.image_url,
        price: product.price,
        price_type: product.price_type,
        category: product.category,
        selected_options: options,
        quantity: qty,
        line_total: product.price * qty,
      },
    })
  }

  const removeItem = (productId: string) => dispatch({ type: 'REMOVE_ITEM', payload: productId })
  const updateQty = (productId: string, quantity: number) =>
    dispatch({ type: 'UPDATE_QTY', payload: { product_id: productId, quantity } })
  const clearCart = () => dispatch({ type: 'CLEAR_CART' })
  const openCart = () => dispatch({ type: 'TOGGLE_CART', payload: true })
  const closeCart = () => dispatch({ type: 'TOGGLE_CART', payload: false })

  const itemCount = state.items.reduce((sum, i) => sum + i.quantity, 0)
  const subtotal = state.items.reduce((sum, i) => sum + i.line_total, 0)

  return (
    <CartContext.Provider
      value={{ ...state, addItem, removeItem, updateQty, clearCart, openCart, closeCart, itemCount, subtotal }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
